package com.rezero;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;

/**
 * Fuego amarillo: variante del fuego normal. Hace la mitad de dano (0.5 por segundo, el fuego normal hace 1),
 * cuenta como dano de fuego (la Resistencia al fuego lo anula), se apaga en el agua y frena la recarga de mana.
 * El efecto visual en pantalla lo dibuja client/YellowFireOverlay.
 */
public class YellowFireEffect extends MobEffect {
    public YellowFireEffect() {
        super(MobEffectCategory.HARMFUL, 0xFFD21E);
    }

    @Override
    public boolean applyEffectTick(LivingEntity entity, int amplifier) {
        if (!entity.level().isClientSide) {
            entity.hurt(entity.damageSources().onFire(), 0.5F * (amplifier + 1));
        }
        return true;
    }

    @Override
    public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
        return duration % 20 == 0;
    }
}
