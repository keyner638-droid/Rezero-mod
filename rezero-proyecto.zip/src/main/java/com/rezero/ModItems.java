package com.rezero;

import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ReZero.MODID);

    public static final DeferredItem<HappyBirthdayItem> HAPPY_BIRTHDAY =
            ITEMS.registerItem("happy_birthday", HappyBirthdayItem::new, new Item.Properties().stacksTo(1));

    /** Moneda: la cantidad de la pila es el valor en cobre. Al tocarla se suma al total y no entra al inventario. */
    public static final DeferredItem<Item> COIN =
            ITEMS.registerItem("coin", Item::new, new Item.Properties().stacksTo(99));

    private ModItems() {}
}
