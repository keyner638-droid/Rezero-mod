package com.rezero;

import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ReZero.MODID);

    public static final DeferredItem<HappyBirthdayItem> HAPPY_BIRTHDAY =
            ITEMS.registerItem("happy_birthday", HappyBirthdayItem::new, new Item.Properties().stacksTo(1));

    public static final DeferredItem<CrystalItem> MANA_CRYSTAL = ITEMS.registerItem("mana_crystal",
            props -> new CrystalItem(props, CrystalItem.Kind.MANA), new Item.Properties().stacksTo(99));

    public static final DeferredItem<CrystalItem> LIFE_CRYSTAL = ITEMS.registerItem("life_crystal",
            props -> new CrystalItem(props, CrystalItem.Kind.LIFE), new Item.Properties().stacksTo(99));

    public static final DeferredItem<WandItem> WAND =
            ITEMS.registerItem("wand", WandItem::new, new Item.Properties().stacksTo(1));

    private ModItems() {}
}
