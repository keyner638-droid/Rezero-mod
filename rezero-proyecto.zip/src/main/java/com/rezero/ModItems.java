package com.rezero;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ReZero.MODID);

    public static final DeferredItem<HappyBirthdayItem> HAPPY_BIRTHDAY =
            ITEMS.registerItem("happy_birthday", HappyBirthdayItem::new, new Item.Properties().stacksTo(1));

    public static final DeferredItem<CrystalItem> MANA_CRYSTAL = ITEMS.registerItem("mana_crystal",
            props -> new CrystalItem(props, CrystalItem.Kind.MANA), new Item.Properties().stacksTo(99));

    public static final DeferredItem<CrystalItem> LIFE_CRYSTAL = ITEMS.registerItem("life_crystal",
            props -> new CrystalItem(props, CrystalItem.Kind.LIFE), new Item.Properties().stacksTo(99));

    /** Material para craftear la varita. */
    public static final DeferredItem<Item> STAR =
            ITEMS.registerItem("star", Item::new, new Item.Properties());

    /** Pergamino que suelta el Zombie Mago Errante (sin funcion todavia). */
    public static final DeferredItem<ScrollItem> SCROLL =
            ITEMS.registerItem("scroll", ScrollItem::new, new Item.Properties().stacksTo(64));

    /** Sombrero del Mago Errante (2% de probabilidad al matarlo). Se lleva en la cabeza. */
    public static final DeferredItem<WanderingMageHatItem> WANDERING_MAGE_HAT =
            ITEMS.registerItem("wandering_mage_hat",
                    props -> new WanderingMageHatItem(ModArmorMaterials.WANDERING_MAGE_HAT, props),
                    new Item.Properties().stacksTo(1).rarity(Rarity.RARE));

    public static final DeferredItem<DeferredSpawnEggItem> WANDERING_ZOMBIE_MAGE_SPAWN_EGG =
            ITEMS.register("wandering_zombie_mage_spawn_egg",
                    () -> new DeferredSpawnEggItem(ModEntities.WANDERING_ZOMBIE_MAGE, 0x4C2A7A, 0xE8A93A, new Item.Properties()));

    public static final DeferredItem<WandItem> WAND =
            ITEMS.registerItem("wand", WandItem::new, new Item.Properties().stacksTo(1));

    private ModItems() {}
}
