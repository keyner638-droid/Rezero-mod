package com.rezero;

import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ReZero.MODID);

    public static final DeferredItem<HappyBirthdayItem> HAPPY_BIRTHDAY =
            ITEMS.registerItem("happy_birthday", HappyBirthdayItem::new, new Item.Properties().stacksTo(1));

    private ModItems() {}
}
