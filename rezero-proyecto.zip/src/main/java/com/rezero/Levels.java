package com.rezero;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

/**
 * Niveles propios. Se guarda solo la XP total; para pasar del nivel L al L+1 hacen falta 100 + 40*L de XP.
 */
public final class Levels {
    private Levels() {}

    public static int needed(int level) {
        return 100 + 40 * level;
    }

    /** XP total acumulada necesaria para estar en ese nivel. */
    public static long totalForLevel(int level) {
        return 100L * level + 20L * level * (level - 1L);
    }

    public static int levelOf(long xp) {
        int l = 0;
        while (totalForLevel(l + 1) <= xp) l++;
        return l;
    }

    public static void add(ServerPlayer player, long amount) {
        if (amount <= 0) return;
        long before = player.getData(Coins.XP);
        long after = before + amount;
        player.setData(Coins.XP, after);
        Coins.sync(player);

        int oldLevel = levelOf(before), newLevel = levelOf(after);
        if (newLevel > oldLevel) {
            int gained = newLevel - oldLevel;
            int points = player.getData(Coins.POINTS) + gained;
            player.setData(Coins.POINTS, points);
            Coins.sync(player);
            player.displayClientMessage(Component.literal("¡Nivel " + newLevel + "! +" + gained
                    + (gained == 1 ? " punto" : " puntos") + " (" + points + ")"), true);
            if (player.level() instanceof net.minecraft.server.level.ServerLevel sl) levelUpParticles(sl, player);
            player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.75F, 1.0F);
        }
    }

    /** Anillo de destellos que sube alrededor del jugador y un pequeno estallido dorado. */
    private static void levelUpParticles(net.minecraft.server.level.ServerLevel sl, ServerPlayer player) {
        double x = player.getX(), y = player.getY() + 0.1, z = player.getZ();
        int n = 16;
        for (int i = 0; i < n; i++) {
            double ang = 2 * Math.PI * i / n;
            // count = 0: los "delta" son la direccion y speed la velocidad (sube en vertical)
            sl.sendParticles(net.minecraft.core.particles.ParticleTypes.END_ROD,
                    x + Math.cos(ang) * 0.9, y, z + Math.sin(ang) * 0.9, 0, 0.0, 1.0, 0.0, 0.12);
        }
        sl.sendParticles(net.minecraft.core.particles.ParticleTypes.TOTEM_OF_UNDYING,
                x, y + 1.0, z, 12, 0.4, 0.6, 0.4, 0.15);
    }
}
