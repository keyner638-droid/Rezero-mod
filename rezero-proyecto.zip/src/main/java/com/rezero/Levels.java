package com.rezero;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

/**
 * Niveles propios. Se guarda solo la XP total; para pasar del nivel L al L+1 hacen falta 100 + 40*L de XP.
 */
public final class Levels {
    private Levels() {}

    public static int needed(int level) {
        return 100 + 40 * level;
    }

    /** XP total acumulada necesaria para estar en ese nivel. */
    public static long totalForLevel(int level) {
        return 100L * level + 20L * level * (level - 1L);
    }

    public static int levelOf(long xp) {
        int l = 0;
        while (totalForLevel(l + 1) <= xp) l++;
        return l;
    }

    public static void add(ServerPlayer player, long amount) {
        if (amount <= 0) return;
        long before = player.getData(Coins.XP);
        long after = before + amount;
        player.setData(Coins.XP, after);
        Coins.sync(player);

        int oldLevel = levelOf(before), newLevel = levelOf(after);
        if (newLevel > oldLevel) {
            player.displayClientMessage(Component.literal("¡Nivel " + newLevel + "!"), true);
            player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.75F, 1.0F);
        }
    }
}
