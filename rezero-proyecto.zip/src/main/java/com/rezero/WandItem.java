package com.rezero;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Varita: lanza una chispa que hace poco dano y gasta mana. Alcance corto (7 bloques por defecto) y con gravedad:
 * la chispa describe una curva y cae un poco al llegar al final (config: wandRangeBlocks / wandDropAtMaxRange).
 */
public class WandItem extends Item {
    /** Longitud de cada tramo de la trayectoria, en bloques. */
    private static final double STEP = 0.5;

    public WandItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp) || !(level instanceof ServerLevel sl)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }
        if (!Mana.consume(sp, Config.WAND_MANA_COST.get())) {
            sp.displayClientMessage(Component.literal("Sin mana"), true);
            return InteractionResultHolder.fail(stack);
        }
        player.getCooldowns().addCooldown(this, Config.WAND_COOLDOWN_TICKS.get());

        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getLookAngle();

        // Trayectoria por tramos: cada tramo la velocidad baja un poco en vertical (gravedad).
        // Tras n tramos la caida es g*n*(n+1)/2; g se calcula para que a maximo alcance caiga WAND_DROP bloques.
        int steps = Math.max(1, (int) Math.ceil(Config.WAND_RANGE.get() / STEP));
        double g = 2.0 * Config.WAND_DROP.get() / (steps * (steps + 1.0));

        Vec3 pos = eye;
        Vec3 vel = look.scale(STEP);
        Vec3 stop = null;
        Entity target = null;
        for (int i = 0; i < steps && stop == null; i++) {
            vel = vel.add(0.0, -g, 0.0);
            Vec3 next = pos.add(vel);

            BlockHitResult block = sl.clip(new ClipContext(pos, next, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
            Vec3 segEnd = block.getType() == HitResult.Type.MISS ? next : block.getLocation();

            EntityHitResult hit = ProjectileUtil.getEntityHitResult(sl, sp, pos, segEnd, new AABB(pos, segEnd).inflate(0.5),
                    e -> !e.isSpectator() && e.isPickable() && e != sp);
            if (hit != null) {
                segEnd = hit.getLocation();
                target = hit.getEntity();
                stop = segEnd;
            } else if (block.getType() != HitResult.Type.MISS) {
                stop = segEnd;
            }

            spark(sl, pos, segEnd, eye);
            pos = next;
        }
        if (stop == null) stop = pos;

        if (target != null) {
            DamageSource source = sl.damageSources().indirectMagic(sp, sp); // el golpe cuenta como del jugador (monedas/XP)
            target.hurt(source, (float) (Config.WAND_DAMAGE.get() * com.rezero.rune.RuneEffects.magicMultiplier(sp))); // Runa del Espiritu     // dano magico: no prende fuego
        }
        sl.sendParticles(ParticleTypes.CRIT, stop.x, stop.y, stop.z, 4, 0.1, 0.1, 0.1, 0.05);
        sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.FLINTANDSTEEL_USE, SoundSource.PLAYERS, 0.5F, 1.7F);
        return InteractionResultHolder.sidedSuccess(stack, false);
    }

    /** Chispas a lo largo de un tramo (no en los primeros 0.8 bloques, para no taparse la vista). */
    private static void spark(ServerLevel sl, Vec3 from, Vec3 to, Vec3 eye) {
        double len = from.distanceTo(to);
        if (len <= 0.0) return;
        Vec3 dir = to.subtract(from).scale(1.0 / len);
        for (double d = 0.0; d < len; d += 0.25) {
            Vec3 p = from.add(dir.scale(d));
            if (p.distanceToSqr(eye) < 0.64) continue;
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y - 0.15, p.z, 1, 0, 0, 0, 0);
        }
    }
}
