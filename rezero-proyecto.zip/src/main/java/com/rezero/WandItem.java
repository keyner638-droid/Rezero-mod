package com.rezero;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Varita: lanza una chispa instantanea (no quema) que hace poco dano y gasta mana. */
public class WandItem extends Item {
    private static final double RANGE = 24.0;

    public WandItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp) || !(level instanceof ServerLevel sl)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }
        if (!Mana.consume(sp, Config.WAND_MANA_COST.get())) {
            sp.displayClientMessage(Component.literal("Sin mana"), true);
            return InteractionResultHolder.fail(stack);
        }
        player.getCooldowns().addCooldown(this, Config.WAND_COOLDOWN_TICKS.get());

        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getLookAngle();
        Vec3 end = eye.add(look.scale(RANGE));

        BlockHitResult block = sl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        Vec3 stop = block.getType() == HitResult.Type.MISS ? end : block.getLocation();

        AABB box = sp.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(sl, sp, eye, stop, box,
                e -> !e.isSpectator() && e.isPickable() && e != sp);
        if (hit != null) {
            stop = hit.getLocation();
            Entity target = hit.getEntity();
            DamageSource source = sl.damageSources().indirectMagic(sp, sp); // el golpe cuenta como del jugador (monedas/XP)
            target.hurt(source, Config.WAND_DAMAGE.get().floatValue());   // dano magico: no prende fuego
        }

        double dist = eye.distanceTo(stop);
        for (double d = 0.8; d < dist; d += 0.4) {
            Vec3 p = eye.add(look.scale(d)).add(0, -0.15, 0);
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
        sl.sendParticles(ParticleTypes.CRIT, stop.x, stop.y, stop.z, 4, 0.1, 0.1, 0.1, 0.05);
        sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.FIREWORK_ROCKET_TWINKLE, SoundSource.PLAYERS, 0.8F, 1.4F);
        return InteractionResultHolder.sidedSuccess(stack, false);
    }
}
