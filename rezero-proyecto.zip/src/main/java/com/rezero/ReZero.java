package com.rezero;

import com.rezero.client.ClientSetup;
import com.rezero.client.ClientCoins;
import com.rezero.client.ReturnEffect;
import com.rezero.net.CoinsPayload;
import com.rezero.net.ReturnEndPayload;
import com.rezero.net.ReturnPayload;
import com.rezero.rewind.ReturnByDeath;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

@Mod(ReZero.MODID)
public class ReZero {
    public static final String MODID = "rezero";

    public ReZero(IEventBus modBus, ModContainer container) {
        ModEffects.EFFECTS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
        ModArmorMaterials.MATERIALS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModSlimes.ENTITIES.register(modBus);
        ModItems.ITEMS.register(modBus);
        com.rezero.rune.RuneComponents.COMPONENTS.register(modBus);
        ModMenus.MENUS.register(modBus);
        ModLootModifiers.LOOT_MODIFIERS.register(modBus);
        modBus.addListener(com.rezero.rune.VanillaEnchants::onCreativeTab);
        modBus.addListener(ModCreativeTabs::onBuildTabs);
        ModSounds.SOUNDS.register(modBus);
        Coins.ATTACHMENTS.register(modBus);
        container.registerConfig(ModConfig.Type.COMMON, Config.SPEC);

        modBus.addListener(this::registerPayloads);
        modBus.addListener(ModEntities::registerAttributes);
        modBus.addListener(ModSlimes::registerAttributes);
        modBus.addListener(ModSlimes::registerSpawnPlacements);
        modBus.addListener(ModEntities::registerSpawnPlacements);

        ModEffects.register();
        ReturnByDeath.register();
        CoinEvents.register();
        LevelEvents.register();
        Mana.register();
        com.rezero.rune.RuneCommand.register();
        LevelCommand.register();
        com.rezero.rune.ForgeEvents.register();
        com.rezero.rune.RuneEffects.register();
        com.rezero.rune.VanillaEnchants.register();
        CrystalItem.register();
        if (FMLEnvironment.dist == Dist.CLIENT) ClientSetup.init(modBus);
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        var reg = event.registrar("1");
        reg.playToClient(
                ReturnPayload.TYPE,
                ReturnPayload.STREAM_CODEC,
                (payload, ctx) -> ctx.enqueueWork(() -> ReturnEffect.start(ReturnVariant.byId(payload.variant()))));
        reg.playToClient(
                ReturnEndPayload.TYPE,
                ReturnEndPayload.STREAM_CODEC,
                (payload, ctx) -> ctx.enqueueWork(ReturnEffect::finish));
        reg.playToClient(
                CoinsPayload.TYPE,
                CoinsPayload.STREAM_CODEC,
                (payload, ctx) -> ctx.enqueueWork(() -> {
                    ClientCoins.copper = payload.copper();
                    ClientCoins.xp = payload.xp();
                    ClientCoins.mana = payload.mana();
                    ClientCoins.maxMana = payload.maxMana();
                    ClientCoins.points = payload.points();
                }));
    }
}
