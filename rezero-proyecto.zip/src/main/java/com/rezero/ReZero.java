package com.rezero;

import com.rezero.client.ClientSetup;
import com.rezero.client.ClientCoins;
import com.rezero.client.ReturnEffect;
import com.rezero.net.CoinsPayload;
import com.rezero.net.ReturnEndPayload;
import com.rezero.net.ReturnPayload;
import com.rezero.rewind.ReturnByDeath;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

@Mod(ReZero.MODID)
public class ReZero {
    public static final String MODID = "rezero";

    public ReZero(IEventBus modBus, ModContainer container) {
        ModItems.ITEMS.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        Coins.ATTACHMENTS.register(modBus);
        container.registerConfig(ModConfig.Type.COMMON, Config.SPEC);

        modBus.addListener(this::registerPayloads);
        modBus.addListener(this::addToCreativeTab);

        ReturnByDeath.register();
        CoinEvents.register();
        LevelEvents.register();
        Mana.register();
        CrystalItem.register();
        if (FMLEnvironment.dist == Dist.CLIENT) ClientSetup.init(modBus);
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        var reg = event.registrar("1");
        reg.playToClient(
                ReturnPayload.TYPE,
                ReturnPayload.STREAM_CODEC,
                (payload, ctx) -> ctx.enqueueWork(() -> ReturnEffect.start(ReturnVariant.byId(payload.variant()))));
        reg.playToClient(
                ReturnEndPayload.TYPE,
                ReturnEndPayload.STREAM_CODEC,
                (payload, ctx) -> ctx.enqueueWork(ReturnEffect::finish));
        reg.playToClient(
                CoinsPayload.TYPE,
                CoinsPayload.STREAM_CODEC,
                (payload, ctx) -> ctx.enqueueWork(() -> {
                    ClientCoins.copper = payload.copper();
                    ClientCoins.xp = payload.xp();
                    ClientCoins.mana = payload.mana();
                    ClientCoins.maxMana = payload.maxMana();
                }));
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.HAPPY_BIRTHDAY);
            event.accept(ModItems.MANA_CRYSTAL);
            event.accept(ModItems.LIFE_CRYSTAL);
            event.accept(ModItems.WAND);
        }
    }
}
