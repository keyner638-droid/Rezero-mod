package com.rezero;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

/**
 * Cristales consumibles y permanentes (se conservan al morir de verdad, pero se revierten con el retorno por muerte).
 * Los limites se miden SIEMPRE por cuantos cristales se han consumido, nunca por la vida/mana maxima actual
 * (que puede cambiar por armaduras, sombreros, efectos...):
 *  - Cristal de mana: +10 de mana maxima, hasta {@link #MAX_MANA_CRYSTALS} cristales.
 *  - Cristal de vida: +1 de vida maxima (medio corazon), hasta {@link #MAX_LIFE_CRYSTALS} cristales (30 corazones en total).
 */
public class CrystalItem extends Item {
    public enum Kind { MANA, LIFE }

    public static final int MANA_PER_CRYSTAL = 10;
    public static final int LIFE_PER_CRYSTAL = 1;
    /** 90 cristales = +900 de mana (1000 en total con la mana base por defecto). */
    public static final int MAX_MANA_CRYSTALS = 90;
    /** 40 cristales = 20 corazones extra => 30 corazones con los 10 normales. */
    public static final int MAX_LIFE_CRYSTALS = 40;

    private static final ResourceLocation LIFE_MODIFIER =
            ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "life_crystals");

    private final Kind kind;

    public CrystalItem(Properties properties, Kind kind) {
        super(properties);
        this.kind = kind;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            if (kind == Kind.MANA) {
                int used = sp.getData(Coins.MANA_CRYSTALS);
                if (used >= MAX_MANA_CRYSTALS) {
                    sp.displayClientMessage(Component.literal("Ya consumiste todos los cristales de maná (" + MAX_MANA_CRYSTALS + ")."), true);
                    return InteractionResultHolder.fail(stack);
                }
                sp.setData(Coins.MANA_CRYSTALS, used + 1);
                Mana.add(sp, MANA_PER_CRYSTAL);
                Coins.sync(sp);
                sp.displayClientMessage(Component.literal("Cristales de maná: " + (used + 1) + " / " + MAX_MANA_CRYSTALS), true);
            } else {
                int used = sp.getData(Coins.LIFE_CRYSTALS);
                if (used >= MAX_LIFE_CRYSTALS) {
                    sp.displayClientMessage(Component.literal("Ya consumiste todos los cristales de vida (" + MAX_LIFE_CRYSTALS + ")."), true);
                    return InteractionResultHolder.fail(stack);
                }
                sp.setData(Coins.LIFE_CRYSTALS, used + 1);
                applyLifeBonus(sp);
                sp.heal(LIFE_PER_CRYSTAL);
                sp.displayClientMessage(Component.literal("Cristales de vida: " + (used + 1) + " / " + MAX_LIFE_CRYSTALS), true);
            }
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.0F);
            if (!player.getAbilities().instabuild) stack.shrink(1);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    /** (Re)aplica la vida extra de los cristales; el modificador no se guarda, se pone al entrar y al reaparecer. */
    public static void applyLifeBonus(ServerPlayer player) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr == null) return;
        attr.removeModifier(LIFE_MODIFIER);
        int bonus = Math.min(MAX_LIFE_CRYSTALS, player.getData(Coins.LIFE_CRYSTALS)) * LIFE_PER_CRYSTAL;
        if (bonus > 0) {
            attr.addTransientModifier(new AttributeModifier(LIFE_MODIFIER, bonus, AttributeModifier.Operation.ADD_VALUE));
        }
    }

    /** Partidas de versiones anteriores guardaban puntos de bonus; se pasan una sola vez a cristales consumidos. */
    private static void migrateLegacy(ServerPlayer p) {
        int legacyMana = p.getData(Coins.LEGACY_MANA_BONUS);
        if (legacyMana > 0) {
            p.setData(Coins.MANA_CRYSTALS, p.getData(Coins.MANA_CRYSTALS) + legacyMana / MANA_PER_CRYSTAL);
            p.setData(Coins.LEGACY_MANA_BONUS, 0);
        }
        int legacyLife = p.getData(Coins.LEGACY_LIFE_BONUS);
        if (legacyLife > 0) {
            p.setData(Coins.LIFE_CRYSTALS, p.getData(Coins.LIFE_CRYSTALS) + legacyLife / LIFE_PER_CRYSTAL);
            p.setData(Coins.LEGACY_LIFE_BONUS, 0);
        }
    }

    public static void register() {
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedInEvent e) -> {
            if (e.getEntity() instanceof ServerPlayer p) {
                migrateLegacy(p);
                applyLifeBonus(p);
            }
        });
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerRespawnEvent e) -> {
            if (e.getEntity() instanceof ServerPlayer p) {
                migrateLegacy(p);
                applyLifeBonus(p);
                p.setHealth(p.getMaxHealth());
            }
        });
    }
}
