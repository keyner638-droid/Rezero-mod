package com.rezero;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

/**
 * Cristales consumibles y permanentes (se conservan al morir de verdad, pero se revierten con el retorno por muerte):
 *  - Cristal de mana: +10 de mana maxima (tope 1000).
 *  - Cristal de vida: +1 de vida maxima (medio corazon; tope 30 corazones en total).
 */
public class CrystalItem extends Item {
    public enum Kind { MANA, LIFE }

    public static final int MANA_PER_CRYSTAL = 10;
    public static final int LIFE_PER_CRYSTAL = 1;
    /** Vida extra maxima por cristales: 20 corazones (40 puntos) => 30 corazones con los 10 normales. */
    public static final int MAX_LIFE_BONUS = 40;

    private static final ResourceLocation LIFE_MODIFIER =
            ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "life_crystals");

    private final Kind kind;

    public CrystalItem(Properties properties, Kind kind) {
        super(properties);
        this.kind = kind;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            if (kind == Kind.MANA) {
                if (Mana.max(sp) >= Mana.CAP) {
                    sp.displayClientMessage(Component.literal("Ya tienes la mana máxima (" + Mana.CAP + ")."), true);
                    return InteractionResultHolder.fail(stack);
                }
                sp.setData(Coins.MANA_BONUS, sp.getData(Coins.MANA_BONUS) + MANA_PER_CRYSTAL);
                Mana.add(sp, MANA_PER_CRYSTAL);
                Coins.sync(sp);
                sp.displayClientMessage(Component.literal("Mana máxima: " + Mana.max(sp)), true);
            } else {
                if (sp.getData(Coins.LIFE_BONUS) >= MAX_LIFE_BONUS) {
                    sp.displayClientMessage(Component.literal("Ya tienes la vida máxima (30 corazones)."), true);
                    return InteractionResultHolder.fail(stack);
                }
                sp.setData(Coins.LIFE_BONUS, sp.getData(Coins.LIFE_BONUS) + LIFE_PER_CRYSTAL);
                applyLifeBonus(sp);
                sp.heal(LIFE_PER_CRYSTAL);
                sp.displayClientMessage(Component.literal("Vida máxima: " + (int) sp.getMaxHealth()), true);
            }
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.0F);
            if (!player.getAbilities().instabuild) stack.shrink(1);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    /** (Re)aplica la vida extra de los cristales; el modificador no se guarda, se pone al entrar y al reaparecer. */
    public static void applyLifeBonus(ServerPlayer player) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr == null) return;
        attr.removeModifier(LIFE_MODIFIER);
        int bonus = player.getData(Coins.LIFE_BONUS);
        if (bonus > 0) {
            attr.addTransientModifier(new AttributeModifier(LIFE_MODIFIER, bonus, AttributeModifier.Operation.ADD_VALUE));
        }
    }

    public static void register() {
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedInEvent e) -> {
            if (e.getEntity() instanceof ServerPlayer p) applyLifeBonus(p);
        });
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerRespawnEvent e) -> {
            if (e.getEntity() instanceof ServerPlayer p) {
                applyLifeBonus(p);
                p.setHealth(p.getMaxHealth());
            }
        });
    }
}
