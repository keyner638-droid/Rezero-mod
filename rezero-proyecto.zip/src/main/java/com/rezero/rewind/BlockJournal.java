package com.rezero.rewind;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;

/**
 * Diario de cambios de bloques desde un punto de retorno.
 * Guarda, por cada posicion, como era ANTES del primer cambio (= como estaba en el punto).
 * Asi restaurar es poner cada posicion una sola vez, sin importar cuantas veces cambio.
 */
public final class BlockJournal {
    /** true mientras el propio retorno coloca bloques (para no anotarlos). */
    static boolean suspended = false;

    public record Entry(BlockState state, CompoundTag blockEntity) {}

    private final ResourceKey<Level> dimension;
    private final int centerX, centerZ, radius, max;
    private final Long2ObjectOpenHashMap<Entry> changes = new Long2ObjectOpenHashMap<>();
    boolean overflow = false;

    BlockJournal(ResourceKey<Level> dimension, BlockPos center, int radius, int max) {
        this.dimension = dimension;
        this.centerX = center.getX();
        this.centerZ = center.getZ();
        this.radius = radius;
        this.max = max;
    }

    void record(ServerLevel level, BlockPos pos, LevelChunk chunk, BlockState newState) {
        if (overflow || level.dimension() != dimension) return;
        if (Math.abs(pos.getX() - centerX) > radius || Math.abs(pos.getZ() - centerZ) > radius) return;

        long key = pos.asLong();
        if (changes.containsKey(key)) return;

        BlockState old = chunk.getBlockState(pos);
        if (old == newState) return;

        if (changes.size() >= max) {
            overflow = true;
            return;
        }
        BlockEntity be = chunk.getBlockEntities().get(pos);
        CompoundTag tag = be == null ? null : be.saveWithFullMetadata(level.registryAccess());
        changes.put(key, new Entry(old, tag));
    }

    long[] keys() {
        return changes.keySet().toLongArray();
    }

    Entry get(long key) {
        return changes.get(key);
    }

    void clear() {
        changes.clear();
        overflow = false;
    }
}
