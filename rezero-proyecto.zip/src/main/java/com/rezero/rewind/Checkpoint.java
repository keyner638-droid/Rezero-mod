package com.rezero.rewind;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;

/** Foto del momento: jugador, mobs, items y contenido de cofres/hornos alrededor. (Los bloques los recuerda BlockJournal.) */
public final class Checkpoint {
    final ResourceKey<Level> dimension;
    final BlockPos center;
    final int radius;

    // Jugador
    final double x, y, z;
    final float yRot, xRot;
    final ListTag inventory;
    final CompoundTag food = new CompoundTag();
    final int xpLevel, xpTotal;
    final float xpProgress;
    final List<MobEffectInstance> effects = new ArrayList<>();

    // Mundo
    final long dayTime;
    final boolean raining, thundering;
    final Map<UUID, CompoundTag> entities = new HashMap<>();   // entidades "raiz" con sus datos
    final Set<UUID> knownEntities = new HashSet<>();           // todas las que existian (incluye pasajeros)
    final Long2ObjectOpenHashMap<CompoundTag> blockEntities = new Long2ObjectOpenHashMap<>();

    private Checkpoint(ServerPlayer p, ServerLevel level, int radius) {
        this.dimension = level.dimension();
        this.center = p.blockPosition();
        this.radius = radius;
        this.x = p.getX();
        this.y = p.getY();
        this.z = p.getZ();
        this.yRot = p.getYRot();
        this.xRot = p.getXRot();
        this.inventory = p.getInventory().save(new ListTag());
        p.getFoodData().addAdditionalSaveData(food);
        this.xpLevel = p.experienceLevel;
        this.xpTotal = p.totalExperience;
        this.xpProgress = p.experienceProgress;
        for (MobEffectInstance e : p.getActiveEffects()) effects.add(new MobEffectInstance(e));
        this.dayTime = level.getDayTime();
        this.raining = level.isRaining();
        this.thundering = level.isThundering();
    }

    static Checkpoint capture(ServerPlayer p, int radius) {
        ServerLevel level = p.serverLevel();
        Checkpoint cp = new Checkpoint(p, level, radius);

        // Mobs, items, vehiculos...
        for (Entity e : level.getEntities((Entity) null, cp.area(level), en -> !(en instanceof Player))) {
            cp.knownEntities.add(e.getUUID());
            CompoundTag tag = new CompoundTag();
            if (e.save(tag)) cp.entities.put(e.getUUID(), tag);
        }

        // Contenido de cofres, hornos, etc. (cambia sin que cambie el bloque)
        int minCx = (cp.center.getX() - radius) >> 4, maxCx = (cp.center.getX() + radius) >> 4;
        int minCz = (cp.center.getZ() - radius) >> 4, maxCz = (cp.center.getZ() + radius) >> 4;
        for (int cx = minCx; cx <= maxCx; cx++) {
            for (int cz = minCz; cz <= maxCz; cz++) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    BlockPos bp = be.getBlockPos();
                    if (Math.abs(bp.getX() - cp.center.getX()) > radius || Math.abs(bp.getZ() - cp.center.getZ()) > radius) continue;
                    cp.blockEntities.put(bp.asLong(), be.saveWithFullMetadata(level.registryAccess()));
                }
            }
        }
        return cp;
    }

    AABB area(ServerLevel level) {
        return new AABB(center.getX() - radius, level.getMinBuildHeight(), center.getZ() - radius,
                center.getX() + radius + 1, level.getMaxBuildHeight(), center.getZ() + radius + 1);
    }
}
