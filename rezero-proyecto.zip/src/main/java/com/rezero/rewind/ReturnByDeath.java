package com.rezero.rewind;

import com.rezero.Config;
import com.rezero.net.ReturnPayload;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Retorno por la Muerte.
 *  - Cada pocos segundos se guarda un punto (jugador + mobs + cofres) y se empieza a anotar cada bloque que cambia.
 *  - Al "morir" la muerte se cancela: el jugador no muere de verdad. Se reproduce el negro con parpadeos y,
 *    mientras la pantalla esta negra, el mundo vuelve a como estaba en el punto.
 */
public final class ReturnByDeath {
    /** Ticks que pasan antes de empezar a deshacer (la pantalla ya se esta poniendo negra). */
    private static final int REWIND_DELAY_TICKS = 8;

    private static final class PlayerState {
        Checkpoint checkpoint;
        BlockJournal journal;
        RewindTask task;
        long nextCheckpoint = 0;
    }

    private static final Map<UUID, PlayerState> STATES = new HashMap<>();
    private static final List<BlockJournal> JOURNALS = new ArrayList<>();

    private ReturnByDeath() {}

    public static void register() {
        var bus = NeoForge.EVENT_BUS;
        bus.addListener(EventPriority.HIGHEST, ReturnByDeath::onDeath);
        bus.addListener(EventPriority.HIGHEST, ReturnByDeath::onIncomingDamage);
        bus.addListener(ReturnByDeath::onServerTick);
        bus.addListener(ReturnByDeath::onLogin);
        bus.addListener(ReturnByDeath::onLogout);
        bus.addListener(ReturnByDeath::onChangedDimension);
        bus.addListener(ReturnByDeath::onServerStopping);
    }

    /** Lo llama el mixin antes de que cambie cualquier bloque. */
    public static void onBlockSet(LevelChunk chunk, BlockPos pos, BlockState newState) {
        if (JOURNALS.isEmpty() || BlockJournal.suspended) return;
        if (!(chunk.getLevel() instanceof ServerLevel level) || !level.getServer().isSameThread()) return;
        for (int i = 0; i < JOURNALS.size(); i++) JOURNALS.get(i).record(level, pos, chunk, newState);
    }

    // ---------- Muerte ----------
    private static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!Config.ENABLED.get()) return;
        if (event.getSource().is(DamageTypes.GENERIC_KILL)) return; // /kill sigue matando de verdad

        PlayerState st = STATES.get(player.getUUID());
        if (st == null || st.checkpoint == null) return;            // aun no hay punto: muere normal

        event.setCanceled(true);                                    // no se muere
        player.setHealth(player.getMaxHealth());
        player.clearFire();

        if (st.task != null) return;                                // ya esta volviendo
        st.task = new RewindTask(player, st.checkpoint, st.journal, REWIND_DELAY_TICKS);
        PacketDistributor.sendToPlayer(player, new ReturnPayload());
    }

    /** Mientras vuelve al pasado nada le hace dano. */
    private static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        PlayerState st = STATES.get(player.getUUID());
        if (st != null && st.task != null) event.setCanceled(true);
    }

    // ---------- Reloj ----------
    private static void onServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        long now = server.getTickCount();

        for (PlayerState st : STATES.values()) {
            if (st.task != null && st.task.tick(server)) {
                st.task = null;
                st.nextCheckpoint = now + Config.PAUSE_AFTER_RETURN_SECONDS.get() * 20L;
            }
        }

        if (now % 20 != 0 || !Config.ENABLED.get()) return;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            PlayerState st = STATES.computeIfAbsent(player.getUUID(), k -> new PlayerState());
            if (st.task != null) continue;
            if (st.journal != null && st.journal.overflow) st.nextCheckpoint = 0; // demasiados cambios: punto nuevo
            if (now < st.nextCheckpoint || inDanger(player)) continue;
            takeCheckpoint(player, st);
            st.nextCheckpoint = now + Config.CHECKPOINT_SECONDS.get() * 20L;
        }
    }

    /** No se guarda un punto en medio de un peligro: si no, se volveria justo a la trampa. */
    private static boolean inDanger(ServerPlayer p) {
        return p.isDeadOrDying() || p.isInLava() || p.isOnFire() || p.hurtTime > 0
                || p.fallDistance > 3.0F || p.getAirSupply() < p.getMaxAirSupply() / 2;
    }

    private static void takeCheckpoint(ServerPlayer player, PlayerState st) {
        discard(st);
        int radius = Config.RADIUS.get();
        st.checkpoint = Checkpoint.capture(player, radius);
        st.journal = new BlockJournal(st.checkpoint.dimension, st.checkpoint.center, radius, Config.MAX_BLOCK_CHANGES.get());
        JOURNALS.add(st.journal);
    }

    private static void discard(PlayerState st) {
        if (st.journal != null) JOURNALS.remove(st.journal);
        st.journal = null;
        st.checkpoint = null;
    }

    // ---------- Entrar, salir, cambiar de dimension ----------
    private static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        PlayerState st = STATES.computeIfAbsent(player.getUUID(), k -> new PlayerState());
        st.nextCheckpoint = player.server.getTickCount() + 100;
    }

    private static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        PlayerState st = STATES.remove(player.getUUID());
        if (st == null) return;
        if (st.task != null) st.task.finishNow(player.server); // que el mundo no quede a medias
        discard(st);
    }

    private static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        PlayerState st = STATES.get(player.getUUID());
        if (st == null || st.task != null) return;
        discard(st); // el punto era de la otra dimension
        st.nextCheckpoint = player.server.getTickCount() + 40;
    }

    private static void onServerStopping(ServerStoppingEvent event) {
        STATES.clear();
        JOURNALS.clear();
    }
}
