package com.rezero.rewind;

import com.rezero.Config;
import com.rezero.ReturnVariant;
import com.rezero.net.ReturnEndPayload;
import com.rezero.net.ReturnPayload;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Retorno por la Muerte.
 *  - Cada pocos segundos se guarda un punto (jugador + mobs + cofres) y se empieza a anotar cada bloque que cambia.
 *    El punto se serializa repartido en varios ticks; mientras se completa sigue valiendo el anterior.
 *  - Al ir a morir, el golpe mortal se anula: el jugador no muere de verdad. Se reproduce la animacion y,
 *    mientras la pantalla esta negra, el mundo vuelve a como estaba en el punto.
 *  - Al volver hay unos segundos de invulnerabilidad.
 */
public final class ReturnByDeath {
    /** Ticks que pasan antes de empezar a deshacer (la pantalla ya se esta poniendo negra). */
    private static final int REWIND_DELAY_TICKS = 8;
    /** Mobs/block entities que se serializan por tick al capturar un punto. */
    private static final int CAPTURE_BUDGET_PER_TICK = 64;

    private static final class PlayerState {
        Checkpoint checkpoint;          // punto valido (completo)
        BlockJournal journal;
        Checkpoint pending;             // punto que se esta capturando
        BlockJournal pendingJournal;
        RewindTask task;
        long nextCheckpoint = 0;
        long invulnerableUntil = 0;
        ReturnVariant variant = ReturnVariant.NORMAL;
        long startTick = 0;
        long endAt = 0;                 // tick en el que se avisa al cliente de que ya puede "despertar"
    }

    private static final Map<UUID, PlayerState> STATES = new HashMap<>();
    private static final List<BlockJournal> JOURNALS = new ArrayList<>();

    private ReturnByDeath() {}

    public static void register() {
        var bus = NeoForge.EVENT_BUS;
        bus.addListener(EventPriority.LOWEST, ReturnByDeath::onDamagePre);   // golpe mortal (con el dano final ya calculado)
        bus.addListener(EventPriority.HIGHEST, ReturnByDeath::onDeath);      // por si muere por otra via
        bus.addListener(EventPriority.HIGHEST, ReturnByDeath::onIncomingDamage);
        bus.addListener(ReturnByDeath::onServerTick);
        bus.addListener(ReturnByDeath::onLogin);
        bus.addListener(ReturnByDeath::onLogout);
        bus.addListener(ReturnByDeath::onChangedDimension);
        bus.addListener(ReturnByDeath::onServerStopping);
    }

    /** Lo llama el mixin antes de que cambie cualquier bloque. */
    public static void onBlockSet(LevelChunk chunk, BlockPos pos, BlockState newState) {
        if (JOURNALS.isEmpty() || BlockJournal.suspended) return;
        if (!(chunk.getLevel() instanceof ServerLevel level) || !level.getServer().isSameThread()) return;
        for (int i = 0; i < JOURNALS.size(); i++) JOURNALS.get(i).record(level, pos, chunk, newState);
    }

    // ---------- Muerte ----------
    private static boolean canReturn(DamageSource source) {
        return Config.ENABLED.get() && !source.is(DamageTypes.GENERIC_KILL); // /kill sigue matando de verdad
    }

    /**
     * Si el golpe iba a ser mortal se anula antes de aplicarlo: asi no suena el sonido de muerte ni se gasta un totem.
     * Se compara con vida + absorcion porque la absorcion se descuenta despues de este evento.
     */
    private static void onDamagePre(LivingDamageEvent.Pre event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!canReturn(event.getSource())) return;
        PlayerState st = STATES.get(player.getUUID());
        if (st == null || st.checkpoint == null || st.task != null) return;
        if (event.getNewDamage() < player.getHealth() + player.getAbsorptionAmount()) return;

        event.setNewDamage(0.0F);
        startReturn(player, st);
    }

    private static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!canReturn(event.getSource())) return;

        PlayerState st = STATES.get(player.getUUID());
        if (st == null || st.checkpoint == null) return;            // aun no hay punto: muere normal

        event.setCanceled(true);                                    // no se muere
        startReturn(player, st);
    }

    private static void startReturn(ServerPlayer player, PlayerState st) {
        player.setHealth(player.getMaxHealth());
        player.clearFire();

        if (st.task != null) return;                                // ya esta volviendo
        discardPending(st);                                         // el punto a medio capturar ya no sirve
        st.task = new RewindTask(player, st.checkpoint, st.journal, REWIND_DELAY_TICKS);
        st.variant = ReturnVariant.roll(player.getRandom());
        st.startTick = player.server.getTickCount();
        st.endAt = 0;
        PacketDistributor.sendToPlayer(player, new ReturnPayload(st.variant.ordinal()));
    }

    /** Mientras vuelve al pasado, y unos segundos despues, nada le hace dano. */
    private static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (event.getSource().is(DamageTypes.GENERIC_KILL)) return;
        PlayerState st = STATES.get(player.getUUID());
        if (st == null) return;
        if (st.task != null || st.endAt > 0 || player.server.getTickCount() < st.invulnerableUntil) event.setCanceled(true);
    }

    // ---------- Reloj ----------
    private static void onServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        long now = server.getTickCount();

        for (Map.Entry<UUID, PlayerState> entry : STATES.entrySet()) {
            PlayerState st = entry.getValue();
            if (st.task != null) {
                if (st.task.tick(server)) {
                    st.task = null;
                    // El cliente no abre los ojos hasta que acabe la animacion/audio de esta variante.
                    st.endAt = Math.max(now, st.startTick + Math.round(st.variant.wakeSeconds * 20f));
                    st.nextCheckpoint = st.endAt + Config.PAUSE_AFTER_RETURN_SECONDS.get() * 20L;
                    st.invulnerableUntil = st.endAt + Math.round(Config.INVULNERABLE_SECONDS.get() * 20.0);
                }
            } else if (st.pending != null) {
                stepPending(server, st);
            }
            if (st.endAt > 0 && now >= st.endAt) {
                st.endAt = 0;
                ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
                if (player != null) PacketDistributor.sendToPlayer(player, new ReturnEndPayload());
            }
        }

        if (now % 20 != 0 || !Config.ENABLED.get()) return;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            PlayerState st = STATES.computeIfAbsent(player.getUUID(), k -> new PlayerState());
            if (st.task != null || st.pending != null) continue;
            if (st.journal != null && st.journal.overflow) st.nextCheckpoint = 0; // demasiados cambios: punto nuevo
            if (now < st.nextCheckpoint || inDanger(player)) continue;
            beginCheckpoint(player, st);
            st.nextCheckpoint = now + Config.CHECKPOINT_SECONDS.get() * 20L;
        }
    }

    /** No se guarda un punto en medio de un peligro: si no, se volveria justo a la trampa. */
    private static boolean inDanger(ServerPlayer p) {
        return p.isDeadOrDying() || p.isInLava() || p.isOnFire() || p.hurtTime > 0
                || p.fallDistance > 3.0F || p.getAirSupply() < p.getMaxAirSupply() / 2;
    }

    private static void beginCheckpoint(ServerPlayer player, PlayerState st) {
        int radius = Config.RADIUS.get();
        st.pending = Checkpoint.begin(player, radius);
        st.pendingJournal = new BlockJournal(st.pending.dimension, st.pending.center, radius, Config.MAX_BLOCK_CHANGES.get());
        JOURNALS.add(st.pendingJournal);
    }

    /** Serializa un trozo del punto pendiente; al completarse reemplaza al anterior. */
    private static void stepPending(MinecraftServer server, PlayerState st) {
        ServerLevel level = server.getLevel(st.pending.dimension);
        if (level == null || st.pendingJournal.overflow) {
            discardPending(st);
            return;
        }
        if (!st.pending.step(level, CAPTURE_BUDGET_PER_TICK)) return;

        if (st.journal != null) JOURNALS.remove(st.journal);
        st.checkpoint = st.pending;
        st.journal = st.pendingJournal;
        st.pending = null;
        st.pendingJournal = null;
    }

    private static void discardPending(PlayerState st) {
        if (st.pendingJournal != null) JOURNALS.remove(st.pendingJournal);
        st.pendingJournal = null;
        st.pending = null;
    }

    private static void discard(PlayerState st) {
        discardPending(st);
        if (st.journal != null) JOURNALS.remove(st.journal);
        st.journal = null;
        st.checkpoint = null;
    }

    // ---------- Entrar, salir, cambiar de dimension ----------
    private static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        PlayerState st = STATES.computeIfAbsent(player.getUUID(), k -> new PlayerState());
        st.nextCheckpoint = player.server.getTickCount() + 100;
    }

    private static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        PlayerState st = STATES.remove(player.getUUID());
        if (st == null) return;
        if (st.task != null) st.task.finishNow(player.server); // que el mundo no quede a medias
        discard(st);
    }

    private static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        PlayerState st = STATES.get(player.getUUID());
        if (st == null || st.task != null) return;
        discard(st); // el punto era de la otra dimension
        st.nextCheckpoint = player.server.getTickCount() + 40;
    }

    private static void onServerStopping(ServerStoppingEvent event) {
        STATES.clear();
        JOURNALS.clear();
    }
}
