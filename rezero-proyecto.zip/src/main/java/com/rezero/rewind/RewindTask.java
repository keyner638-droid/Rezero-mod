package com.rezero.rewind;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.game.ClientboundSetExperiencePacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.Vec3;

/**
 * El retorno en si, repartido en varios ticks para no congelar el servidor:
 *  espera (mientras la pantalla se pone negra) -> bloques por tandas -> cofres, mobs e items -> jugador y reloj del mundo.
 */
final class RewindTask {
    private static final int BLOCKS_PER_TICK = 5000;

    private final ServerPlayer player;
    private final Checkpoint cp;
    private final BlockJournal journal;
    private int delay;
    private int phase = 0;
    private long[] keys;
    private int index = 0;

    RewindTask(ServerPlayer player, Checkpoint cp, BlockJournal journal, int delayTicks) {
        this.player = player;
        this.cp = cp;
        this.journal = journal;
        this.delay = delayTicks;
    }

    ServerPlayer player() {
        return player;
    }

    /** Devuelve true cuando termino. */
    boolean tick(MinecraftServer server) {
        ServerLevel level = server.getLevel(cp.dimension);
        if (level == null) return true;

        if (phase == 0) {
            if (--delay > 0) return false;
            keys = journal.keys();
            phase = 1;
        }
        if (phase == 1) {
            restoreBlocks(level);
            if (index < keys.length) return false;
            phase = 2;
        }
        restoreBlockEntities(level);
        restoreEntities(level);
        restoreWorldClock(level);
        if (!player.hasDisconnected()) restorePlayer(level);
        journal.clear();
        return true;
    }

    /** Termina todo de golpe (por ejemplo si el jugador se desconecta a mitad). */
    void finishNow(MinecraftServer server) {
        delay = 0;
        while (!tick(server)) { /* sigue */ }
    }

    // ---- Bloques ----
    private void restoreBlocks(ServerLevel level) {
        BlockJournal.suspended = true;
        try {
            BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
            int end = Math.min(keys.length, index + BLOCKS_PER_TICK);
            for (; index < end; index++) {
                BlockJournal.Entry entry = journal.get(keys[index]);
                if (entry == null) continue;
                pos.set(keys[index]);
                level.setBlock(pos, entry.state(), Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
                scheduleTicks(level, pos, entry.state());
                if (entry.blockEntity() != null) loadBlockEntity(level, pos, entry.blockEntity());
            }
        } finally {
            BlockJournal.suspended = false;
        }
    }

    /**
     * Al poner el bloque "a pelo" se pierden los ticks que tenia pendientes: sin esto el agua/lava quedan congeladas,
     * la arena flotando y los botones/repetidores/antorchas de redstone atascados.
     */
    private static void scheduleTicks(ServerLevel level, BlockPos pos, BlockState state) {
        FluidState fluid = state.getFluidState();
        if (!fluid.isEmpty()) {
            level.scheduleTick(pos.immutable(), fluid.getType(), fluid.getType().getTickDelay(level));
        }
        Block block = state.getBlock();
        if (block instanceof FallingBlock || state.isSignalSource()) {
            level.scheduleTick(pos.immutable(), block, 2);
        }
    }

    private void restoreBlockEntities(ServerLevel level) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (long key : cp.blockEntities.keySet().toLongArray()) {
            pos.set(key);
            if (level.hasChunkAt(pos)) loadBlockEntity(level, pos, cp.blockEntities.get(key));
        }
    }

    private static void loadBlockEntity(ServerLevel level, BlockPos pos, CompoundTag tag) {
        BlockEntity be = level.getBlockEntity(pos);
        if (be == null) return;
        ResourceLocation key = BlockEntityType.getKey(be.getType());
        if (key == null || !key.toString().equals(tag.getString("id"))) return;
        be.loadWithComponents(tag, level.registryAccess());
        be.setChanged();
        BlockState state = be.getBlockState();
        level.sendBlockUpdated(pos, state, state, Block.UPDATE_ALL);
    }

    // ---- Mobs, items, vehiculos ----
    private void restoreEntities(ServerLevel level) {
        // Lo que no existia en ese momento desaparece
        List<Entity> now = level.getEntities((Entity) null, cp.area(level), en -> !(en instanceof Player));
        for (Entity e : now) {
            if (!cp.knownEntities.contains(e.getUUID()) && e.getType().canSerialize()) e.discard();
        }
        // Lo que existia vuelve como estaba (si sigue ahi se actualiza, si murio o se fue se recrea)
        for (Map.Entry<UUID, CompoundTag> en : cp.entities.entrySet()) {
            CompoundTag tag = en.getValue().copy();
            Entity existing = level.getEntity(en.getKey());
            if (existing != null && !existing.isRemoved()) {
                existing.load(tag);
            } else if (chunkLoadedAt(level, tag)) {
                // Si su chunk esta descargado puede seguir existiendo alli: no se recrea para no duplicarlo.
                Entity revived = EntityType.loadEntityRecursive(tag, level, e -> e);
                if (revived != null) level.addFreshEntityWithPassengers(revived);
            }
        }
    }

    private static boolean chunkLoadedAt(ServerLevel level, CompoundTag tag) {
        ListTag pos = tag.getList("Pos", Tag.TAG_DOUBLE);
        if (pos.size() < 3) return true;
        return level.hasChunk(Mth.floor(pos.getDouble(0)) >> 4, Mth.floor(pos.getDouble(2)) >> 4);
    }

    // ---- Hora y clima ----
    private void restoreWorldClock(ServerLevel level) {
        if (level.dimension() == Level.OVERWORLD) level.setDayTime(cp.dayTime);
        boolean wet = cp.raining || cp.thundering;
        level.setWeatherParameters(wet ? 0 : 6000, wet ? 6000 : 0, cp.raining, cp.thundering);
    }

    // ---- Jugador ----
    private void restorePlayer(ServerLevel level) {
        player.closeContainer();
        player.stopRiding();
        player.teleportTo(level, cp.x, cp.y, cp.z, cp.yRot, cp.xRot);
        player.setDeltaMovement(Vec3.ZERO);
        player.fallDistance = 0.0F;
        player.clearFire();

        player.getInventory().load(cp.inventory.copy());
        player.getFoodData().readAdditionalSaveData(cp.food.copy());
        player.experienceLevel = cp.xpLevel;
        player.totalExperience = cp.xpTotal;
        player.experienceProgress = cp.xpProgress;
        player.connection.send(new ClientboundSetExperiencePacket(cp.xpProgress, cp.xpTotal, cp.xpLevel));

        player.setData(com.rezero.Coins.XP, cp.xp);
        player.setData(com.rezero.Coins.MANA_CRYSTALS, cp.manaCrystals);
        player.setData(com.rezero.Coins.LIFE_CRYSTALS, cp.lifeCrystals);
        player.setData(com.rezero.Coins.POINTS, cp.points);
        com.rezero.CrystalItem.applyLifeBonus(player);
        player.setData(com.rezero.Coins.MANA, cp.mana);
        com.rezero.Coins.set(player, cp.coins);
        player.removeAllEffects();
        for (MobEffectInstance e : cp.effects) player.addEffect(new MobEffectInstance(e));

        player.setHealth(player.getMaxHealth());
        player.inventoryMenu.broadcastChanges();
        player.hurtMarked = true;
    }
}
