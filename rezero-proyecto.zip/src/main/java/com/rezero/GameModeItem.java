package com.rezero;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;

/** Sello que cambia el modo de juego del que lo usa (clic derecho). Solo se consigue en el creativo (pestana de combate). */
public class GameModeItem extends Item {
    private final GameType mode;

    public GameModeItem(Properties properties, GameType mode) {
        super(properties);
        this.mode = mode;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            if (sp.gameMode.getGameModeForPlayer() == mode) {
                sp.displayClientMessage(Component.translatable("message.rezero.already_mode", mode.getLongDisplayName()), true);
            } else {
                sp.setGameMode(mode);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
