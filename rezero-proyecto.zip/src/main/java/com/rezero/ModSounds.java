package com.rezero;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, ReZero.MODID);

    public static final DeferredHolder<SoundEvent, SoundEvent> RETORNO = register("retorno");
    public static final DeferredHolder<SoundEvent, SoundEvent> HAPPY_BIRTHDAY = register("happy_birthday");

    private static DeferredHolder<SoundEvent, SoundEvent> register(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(ReZero.MODID, name)));
    }

    private ModSounds() {}
}
