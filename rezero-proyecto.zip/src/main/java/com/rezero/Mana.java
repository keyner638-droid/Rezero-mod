package com.rezero;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Mana del jugador. Para armas/habilidades futuras: {@code Mana.consume(player, coste)} devuelve false si no alcanza.
 * Se recupera {@code manaRegenPerSecond} cada segundo.
 */
public final class Mana {
    /** Tope absoluto de mana maxima (base + cristales). */
    public static final int CAP = 1000;

    private Mana() {}

    public static void register() {
        NeoForge.EVENT_BUS.addListener(Mana::onServerTick);
    }

    public static int max(net.minecraft.world.entity.player.Player player) {
        return Math.min(CAP, Config.MAX_MANA.get() + player.getData(Coins.MANA_BONUS));
    }

    public static int get(net.minecraft.world.entity.player.Player player) {
        return Math.max(0, Math.min(player.getData(Coins.MANA), max(player)));
    }

    public static void set(ServerPlayer player, int value) {
        int v = Math.max(0, Math.min(value, max(player)));
        if (v == get(player) && player.getData(Coins.MANA) == v) return;
        player.setData(Coins.MANA, v);
        Coins.sync(player);
    }

    public static void add(ServerPlayer player, int amount) {
        set(player, get(player) + amount);
    }

    /** Gasta mana si hay suficiente. */
    public static boolean consume(ServerPlayer player, int cost) {
        if (get(player) < cost) return false;
        set(player, get(player) - cost);
        return true;
    }

    private static void onServerTick(ServerTickEvent.Post event) {
        if (event.getServer().getTickCount() % 20 != 0) return;
        int regen = Config.MANA_REGEN.get();
        for (ServerPlayer p : event.getServer().getPlayerList().getPlayers()) {
            if (p.isDeadOrDying()) continue;
            if (get(p) < max(p)) add(p, regen);
        }
    }
}
