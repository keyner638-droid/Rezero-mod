package com.rezero;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Mana del jugador. Para armas/habilidades futuras: {@code Mana.consume(player, coste)} devuelve false si no alcanza
 * (aplica solo los descuentos, p. ej. el del Sombrero del Mago Errante).
 * Se recupera {@code manaRegenPerSecond} por segundo (x2.5 tras 3 segundos sin gastar mana).
 *
 * Mana maxima = base (config) + cristales consumidos * 10 + bonus de equipo (sombrero...).
 * El tope de cristales es propio ({@link CrystalItem#MAX_MANA_CRYSTALS}) y no depende del maximo,
 * asi el equipo nunca bloquea ni mezcla la cuenta de los cristales.
 */
public final class Mana {
    private Mana() {}

    public static void register() {
        NeoForge.EVENT_BUS.addListener(Mana::onServerTick);
        NeoForge.EVENT_BUS.addListener(Mana::onLogout);
    }

    /** Mana que dan los cristales consumidos. */
    public static int crystalBonus(net.minecraft.world.entity.player.Player player) {
        int crystals = Math.min(CrystalItem.MAX_MANA_CRYSTALS, player.getData(Coins.MANA_CRYSTALS));
        return crystals * CrystalItem.MANA_PER_CRYSTAL;
    }

    /** Mana extra por equipo puesto. */
    public static int equipmentBonus(net.minecraft.world.entity.player.Player player) {
        return WanderingMageHatItem.isWearing(player) ? Config.HAT_MANA_BONUS.get() : 0;
    }

    /** Multiplicador del coste de mana (1.0 = sin descuento). */
    public static double costMultiplier(net.minecraft.world.entity.player.Player player) {
        if (!WanderingMageHatItem.isWearing(player)) return 1.0;
        return Math.max(0.0, 1.0 - Config.HAT_COST_REDUCTION.get() / 100.0);
    }

    public static int max(net.minecraft.world.entity.player.Player player) {
        return Config.MAX_MANA.get() + crystalBonus(player) + equipmentBonus(player);
    }

    public static int get(net.minecraft.world.entity.player.Player player) {
        return Math.max(0, Math.min(player.getData(Coins.MANA), max(player)));
    }

    public static void set(ServerPlayer player, int value) {
        int v = Math.max(0, Math.min(value, max(player)));
        if (v == get(player) && player.getData(Coins.MANA) == v) return;
        player.setData(Coins.MANA, v);
        Coins.sync(player);
    }

    public static void add(ServerPlayer player, int amount) {
        set(player, get(player) + amount);
    }

    /**
     * Gasta mana si hay suficiente. Con descuento el coste puede ser fraccionario (10 -> 9.5): se cobra la parte
     * entera y la fraccion se acumula para el siguiente uso, asi el descuento se nota aunque el coste sea pequeno.
     */
    public static boolean consume(ServerPlayer player, int cost) {
        UUID id = player.getUUID();
        double mult = costMultiplier(player);
        if (mult >= 1.0) COST_CARRY.remove(id);
        double exact = cost * mult + COST_CARRY.getOrDefault(id, 0.0);
        int actual = (int) Math.floor(exact + 1.0E-9);
        if (get(player) < actual) return false;
        if (mult < 1.0) COST_CARRY.put(id, Math.max(0.0, exact - actual));
        markUsed(player);
        set(player, get(player) - actual);
        return true;
    }

    /** Cuando se uso por ultima vez mana (tick del servidor), mana fraccionaria acumulada, fraccion de coste y ultimo maximo. */
    private static final Map<UUID, Long> LAST_USE = new HashMap<>();
    private static final Map<UUID, Double> FRACTION = new HashMap<>();
    private static final Map<UUID, Double> COST_CARRY = new HashMap<>();
    private static final Map<UUID, Integer> LAST_MAX = new HashMap<>();

    private static void markUsed(ServerPlayer player) {
        LAST_USE.put(player.getUUID(), (long) player.server.getTickCount());
    }

    /** Cada 4 ticks recupera mana; x2.5 si lleva 3 segundos sin gastar mana. */
    private static void onServerTick(ServerTickEvent.Post event) {
        long now = event.getServer().getTickCount();
        if (now % 4 != 0) return;
        double regenPerStep = Config.MANA_REGEN.get() / 20.0 * 4.0;
        long idleTicks = Config.MANA_IDLE_SECONDS.get() * 20L;
        for (ServerPlayer p : event.getServer().getPlayerList().getPlayers()) {
            if (p.isDeadOrDying()) continue;
            UUID id = p.getUUID();

            // Si el maximo cambia (se pone o quita el sombrero...) se recorta la mana guardada y se avisa al cliente.
            int max = max(p);
            Integer lastMax = LAST_MAX.put(id, max);
            if (lastMax != null && lastMax != max) {
                if (p.getData(Coins.MANA) > max) p.setData(Coins.MANA, max);
                Coins.sync(p);
            }

            if (get(p) >= max) {
                FRACTION.remove(id);
                continue;
            }
            boolean idle = now - LAST_USE.getOrDefault(id, -1_000_000L) >= idleTicks;
            double burn = p.hasEffect(ModEffects.YELLOW_FIRE) ? Config.YELLOW_FIRE_MANA_REGEN.get() : 1.0;
            double acc = FRACTION.getOrDefault(id, 0.0) + regenPerStep * burn * (idle ? Config.MANA_IDLE_MULTIPLIER.get() : 1.0);
            int whole = (int) acc;
            FRACTION.put(id, acc - whole);
            if (whole > 0) {
                add(p, whole);
                // Sonido suave (solo para ese jugador) al llegar al maximo recuperando mana.
                if (get(p) >= max) {
                    p.playNotifySound(net.minecraft.sounds.SoundEvents.AMETHYST_BLOCK_CHIME,
                            net.minecraft.sounds.SoundSource.PLAYERS, 0.5F, 1.5F);
                }
            }
        }
    }

    private static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID();
        LAST_USE.remove(id);
        FRACTION.remove(id);
        COST_CARRY.remove(id);
        LAST_MAX.remove(id);
    }
}
