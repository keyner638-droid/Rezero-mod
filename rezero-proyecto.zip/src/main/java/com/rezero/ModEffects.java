package com.rezero;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(Registries.MOB_EFFECT, ReZero.MODID);

    public static final DeferredHolder<MobEffect, YellowFireEffect> YELLOW_FIRE =
            EFFECTS.register("yellow_fire", YellowFireEffect::new);

    private ModEffects() {}

    public static void register() {
        NeoForge.EVENT_BUS.addListener(ModEffects::onPlayerTick);
    }

    /** Como el fuego normal, el agua lo apaga. (Se quita aqui y no dentro del efecto para no tocar la lista mientras se recorre.) */
    private static void onPlayerTick(PlayerTickEvent.Post event) {
        Player p = event.getEntity();
        if (p.level().isClientSide || p.tickCount % 5 != 0) return;
        if (p.isInWater() && p.hasEffect(YELLOW_FIRE)) p.removeEffect(YELLOW_FIRE);
    }
}
