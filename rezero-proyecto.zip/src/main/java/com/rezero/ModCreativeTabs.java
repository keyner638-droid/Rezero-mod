package com.rezero;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Pestana propia del mod en el modo creativo con todos sus items. */
public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ReZero.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("rezero",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.rezero"))
                    .icon(() -> new ItemStack(ModItems.WAND.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.WAND.get());
                        output.accept(ModItems.STAR.get());
                        output.accept(ModItems.SCROLL.get());
                        output.accept(ModItems.WANDERING_MAGE_HAT.get());
                        output.accept(ModItems.MANA_CRYSTAL.get());
                        output.accept(ModItems.LIFE_CRYSTAL.get());
                        output.accept(ModItems.WANDERING_ZOMBIE_MAGE_SPAWN_EGG.get());
                        output.accept(ModItems.HAPPY_BIRTHDAY.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
