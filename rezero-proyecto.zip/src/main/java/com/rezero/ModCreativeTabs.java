package com.rezero;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Pestana propia del mod en el modo creativo con todos sus items. */
public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ReZero.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("rezero",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.rezero"))
                    .icon(() -> new ItemStack(ModItems.WAND.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.WAND.get());
                        output.accept(ModItems.STAR.get());
                        output.accept(ModItems.SCROLL.get());
                        output.accept(ModItems.WANDERING_MAGE_HAT.get());
                        output.accept(ModItems.MANA_CRYSTAL.get());
                        output.accept(ModItems.LIFE_CRYSTAL.get());
                        output.accept(ModItems.WANDERING_ZOMBIE_MAGE_SPAWN_EGG.get());
                        output.accept(ModItems.RED_SLIME_SPAWN_EGG.get());
                        output.accept(ModItems.BLUE_SLIME_SPAWN_EGG.get());
                        output.accept(ModItems.YELLOW_SLIME_SPAWN_EGG.get());
                        output.accept(ModItems.PINK_SLIME_SPAWN_EGG.get());
                        output.accept(ModItems.HAPPY_BIRTHDAY.get());
                    })
                    .build());

    /** Pestana propia de las runas: cada tipo en cada calidad. */
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> RUNES = TABS.register("runes",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.rezero.runes"))
                    .icon(() -> com.rezero.rune.RuneItem.create("fire", com.rezero.rune.Quality.LEGENDARY))
                    .displayItems((params, output) -> {
                        for (var def : com.rezero.rune.RuneRegistry.all()) {
                            for (var q : com.rezero.rune.Quality.values()) {
                                output.accept(com.rezero.rune.RuneItem.create(def.id(), q));
                            }
                        }
                    })
                    .build());

    /** Los sellos de modo de juego solo aparecen en la pestana de combate del creativo. */
    public static void onBuildTabs(net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == net.minecraft.world.item.CreativeModeTabs.SPAWN_EGGS) {
            event.remove(new ItemStack(net.minecraft.world.item.Items.SLIME_SPAWN_EGG),
                    CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS);
        }
        if (event.getTabKey() == net.minecraft.world.item.CreativeModeTabs.COMBAT) {
            event.accept(ModItems.CREATIVE_SEAL.get());
            event.accept(ModItems.SURVIVAL_SEAL.get());
        }
    }

    private ModCreativeTabs() {}
}
