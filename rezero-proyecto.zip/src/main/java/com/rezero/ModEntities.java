package com.rezero;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, ReZero.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<WanderingZombieMage>> WANDERING_ZOMBIE_MAGE =
            ENTITIES.register("wandering_zombie_mage", () -> EntityType.Builder
                    .of(WanderingZombieMage::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F)
                    .eyeHeight(1.74F)
                    .clientTrackingRange(8)
                    .build("wandering_zombie_mage"));

    private ModEntities() {}

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(WANDERING_ZOMBIE_MAGE.get(), WanderingZombieMage.createAttributes().build());
    }

    /** Aparece de noche/oscuridad en el suelo, igual que los demas monstruos. */
    public static void registerSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        event.register(WANDERING_ZOMBIE_MAGE.get(), SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.OR);
    }
}
