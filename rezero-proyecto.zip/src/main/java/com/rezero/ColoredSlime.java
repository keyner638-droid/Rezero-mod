package com.rezero;

import javax.annotation.Nullable;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.storage.loot.LootTable;

/** Slime de color: siempre de tamano mediano (2, ~1 bloque) y no se divide al morir. */
public class ColoredSlime extends Slime {
    private static final int SIZE = 2;

    public ColoredSlime(EntityType<? extends Slime> type, Level level) {
        super(type, level);
    }

    /** Tamano fijo en vez del aleatorio (1, 2 o 4) del slime vanilla. */
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType,
                                        @Nullable SpawnGroupData spawnGroupData) {
        SpawnGroupData data = super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData);
        this.setSize(SIZE, true);
        return data;
    }

    /** Slime.remove crea crias si el tamano es mayor que 1: se baja a 1 justo antes de retirarlo (ya esta muerto). */
    @Override
    public void remove(Entity.RemovalReason reason) {
        if (!this.level().isClientSide && this.isDeadOrDying()) {
            this.setSize(1, false);
        }
        super.remove(reason);
    }

    /** El slime vanilla solo suelta loot en tamano 1; aqui siempre se usa su tabla (que ya trae el 2%). */
    @Override
    protected ResourceKey<LootTable> getDefaultLootTable() {
        return this.getType().getDefaultLootTable();
    }
}
