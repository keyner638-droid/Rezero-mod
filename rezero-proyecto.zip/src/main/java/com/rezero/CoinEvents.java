package com.rezero;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.TriState;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.entity.player.ItemEntityPickupEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Las monedas caen como un item "moneda" (cantidad de la pila = cobre) que se atrae hacia el jugador como las orbes
 * de XP y, al tocarlo, se suma al total en vez de ir al inventario.
 */
public final class CoinEvents {
    private static final double MAGNET_RANGE = 6.0;

    private CoinEvents() {}

    public static void register() {
        var bus = NeoForge.EVENT_BUS;
        bus.addListener(CoinEvents::onDrops);
        bus.addListener(CoinEvents::onPickup);
        bus.addListener(CoinEvents::onServerTick);
        bus.addListener(CoinEvents::onLogin);
        bus.addListener(CoinEvents::onRespawn);
        bus.addListener(CoinEvents::onChangedDimension);
    }

    /** Enemigos (agresivos) muertos por un jugador: sueltan entre 50% y 150% de su vida maxima en cobre. */
    private static void onDrops(LivingDropsEvent event) {
        LivingEntity mob = event.getEntity();
        if (mob.level().isClientSide || !(mob instanceof Enemy)) return;
        if (!(event.getSource().getEntity() instanceof ServerPlayer killer)) return;

        // XP directa al numero del jugador (sin orbes, para no generar entidades).
        Levels.add(killer, Math.max(1L, Math.round(mob.getMaxHealth() * Config.XP_PER_HEALTH.get())));

        float max = mob.getMaxHealth();
        long amount = Math.max(1L, Math.round(max * (0.5 + mob.getRandom().nextDouble())));
        while (amount > 0) {
            int part = (int) Math.min(amount, 99L);
            amount -= part;
            ItemEntity coin = new ItemEntity(mob.level(), mob.getX(), mob.getY() + 0.5, mob.getZ(),
                    new ItemStack(ModItems.COIN.get(), part));
            coin.setDefaultPickUpDelay();
            coin.setDeltaMovement((mob.getRandom().nextDouble() - 0.5) * 0.2, 0.25, (mob.getRandom().nextDouble() - 0.5) * 0.2);
            event.getDrops().add(coin);
        }
    }

    /** Tocar una moneda la suma al total (nunca entra al inventario). */
    private static void onPickup(ItemEntityPickupEvent.Pre event) {
        ItemEntity entity = event.getItemEntity();
        ItemStack stack = entity.getItem();
        if (!stack.is(ModItems.COIN.get())) return;
        if (event.getPlayer() instanceof ServerPlayer player) absorb(player, entity);
        event.setCanPickup(TriState.FALSE);
    }

    private static void absorb(ServerPlayer player, ItemEntity entity) {
        if (entity.isRemoved()) return;
        Coins.add(player, entity.getItem().getCount());
        entity.discard();
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.1F, 1.2F + player.getRandom().nextFloat() * 0.4F);
    }

    /** Atrae las monedas cercanas hacia el jugador, como las orbes de XP. */
    private static void onServerTick(ServerTickEvent.Post event) {
        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
            if (player.isSpectator() || player.isDeadOrDying()) continue;
            var box = player.getBoundingBox().inflate(MAGNET_RANGE);
            for (ItemEntity coin : player.level().getEntitiesOfClass(ItemEntity.class, box,
                    e -> e.getItem().is(ModItems.COIN.get()))) {
                if (coin.hasPickUpDelay()) continue;
                Vec3 target = player.position().add(0, player.getBbHeight() / 2.0, 0);
                Vec3 diff = target.subtract(coin.position());
                if (diff.lengthSqr() < 2.0) {
                    absorb(player, coin);
                    continue;
                }
                coin.setDeltaMovement(diff.normalize().scale(Math.min(0.5, 0.15 + 0.5 / Math.max(1.0, diff.length()))));
                coin.hasImpulse = true;
            }
        }
    }

    private static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) Coins.sync(p);
    }

    private static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) Coins.sync(p);
    }

    private static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) Coins.sync(p);
    }
}
