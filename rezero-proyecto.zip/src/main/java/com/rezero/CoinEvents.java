package com.rezero;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

/**
 * Los enemigos agresivos muertos por un jugador dan monedas y XP directamente al numero del jugador
 * (sin items ni orbes, para no generar entidades).
 */
public final class CoinEvents {
    private CoinEvents() {}

    public static void register() {
        var bus = NeoForge.EVENT_BUS;
        bus.addListener(CoinEvents::onDrops);
        bus.addListener(CoinEvents::onLogin);
        bus.addListener(CoinEvents::onRespawn);
        bus.addListener(CoinEvents::onChangedDimension);
    }

    private static void onDrops(LivingDropsEvent event) {
        LivingEntity mob = event.getEntity();
        if (mob.level().isClientSide || !(mob instanceof Enemy)) return;
        if (!(event.getSource().getEntity() instanceof ServerPlayer killer)) return;

        float max = mob.getMaxHealth();

        // XP: vida maxima * xpPerHealth
        Levels.add(killer, Math.max(1L, Math.round(max * Config.XP_PER_HEALTH.get())));

        // Monedas: entre 50% y 150% de la vida maxima, en cobre
        long copper = Math.max(1L, Math.round(max * (0.5 + mob.getRandom().nextDouble())));
        Coins.add(killer, copper);
    }

    private static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) Coins.sync(p);
    }

    private static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) Coins.sync(p);
    }

    private static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) Coins.sync(p);
    }
}
