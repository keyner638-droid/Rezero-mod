package com.rezero.mixin;

import com.rezero.rewind.ReturnByDeath;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Avisa al sistema de retorno justo antes de que cualquier bloque cambie, para recordar como era. */
@Mixin(LevelChunk.class)
public abstract class LevelChunkMixin {
    @Inject(method = "setBlockState", at = @At("HEAD"))
    private void rezero$recordBlock(BlockPos pos, BlockState state, boolean isMoving,
                                    CallbackInfoReturnable<BlockState> cir) {
        ReturnByDeath.onBlockSet((LevelChunk) (Object) this, pos, state);
    }
}
