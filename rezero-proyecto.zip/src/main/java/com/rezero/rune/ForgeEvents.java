package com.rezero.rune;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.AnvilUpdateEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/** El yunque vanilla pasa a ser la Forja Runica: al usarlo abre nuestra pantalla y ya no repara ni combina nada. */
public final class ForgeEvents {
    private ForgeEvents() {}

    public static void register() {
        NeoForge.EVENT_BUS.addListener(ForgeEvents::onRightClickBlock);
        NeoForge.EVENT_BUS.addListener(ForgeEvents::onAnvilUpdate);
    }

    private static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        Level level = event.getLevel();
        var pos = event.getPos();
        if (!level.getBlockState(pos).is(BlockTags.ANVIL)) return;

        Player player = event.getEntity();
        // Agachado con algo en la mano = poner bloques junto al yunque, como siempre.
        if (player.isSecondaryUseActive() && (!player.getMainHandItem().isEmpty() || !player.getOffhandItem().isEmpty())) return;

        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.sidedSuccess(level.isClientSide));
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            sp.openMenu(new SimpleMenuProvider(
                    (id, inv, p) -> new RuneForgeMenu(id, inv, ContainerLevelAccess.create(level, pos)),
                    Component.translatable("container.rezero.rune_forge")));
        }
    }

    /** Por si otro mod abre un yunque normal: sin reparar ni combinar encantamientos. */
    private static void onAnvilUpdate(AnvilUpdateEvent event) {
        event.setCanceled(true);
    }
}
