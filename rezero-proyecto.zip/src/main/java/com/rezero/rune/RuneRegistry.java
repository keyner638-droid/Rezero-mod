package com.rezero.rune;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * Registro de runas. Se lee UNA vez de data/rezero/runes.json (mismo archivo en cliente y servidor).
 * Para anadir una runa: una entrada en runes.json + sus textos en el lang. Sin tocar codigo.
 */
public final class RuneRegistry {
    private static final String PATH = "/data/rezero/runes.json";
    private static Map<String, RuneDef> runes;
    private static Map<String, Integer> capacity;
    private static int defaultCapacity = 4;
    private static Map<String, Double> caps = Map.of();
    private static LootTier lootDefault = new LootTier("", 30.0, 1, new int[]{70, 22, 7, 1, 0});
    private static List<LootTier> lootTiers = List.of();
    private static ForgeRules forgeRules = new ForgeRules(true, true, 4, 3);

    /**
     * Reglas de la Forja (bloque "forge" de runes.json):
     * sameQualityPromotes = dos runas iguales del mismo tipo y calidad se fusionan en una de calidad superior;
     * higherReplaces = una runa de mayor calidad reemplaza a la del mismo tipo que ya esta en el objeto;
     * maxQuality = indice maximo de calidad al que se puede llegar (0 Comun ... 4 Divina);
     * fusionMaxQuality = calidad maxima a la que se puede llegar FUSIONANDO (3 = Legendaria: la Divina no se fusiona).
     */
    public record ForgeRules(boolean sameQualityPromotes, boolean higherReplaces, int maxQuality, int fusionMaxQuality) {}

    /**
     * Regla de loot de cofres. match = trozo del id de la tabla de loot (p. ej. "end_city"); chancePercent = probabilidad
     * de que el cofre lleve runas; rolls = cuantas tiradas; weights = peso de cada calidad (Comun..Divina).
     */
    public record LootTier(String match, double chancePercent, int rolls, int[] weights) {}

    private RuneRegistry() {}

    private static synchronized void load() {
        if (runes != null) return;
        Map<String, RuneDef> r = new LinkedHashMap<>();
        Map<String, Integer> c = new LinkedHashMap<>();
        try (InputStream in = RuneRegistry.class.getResourceAsStream(PATH)) {
            if (in == null) throw new IllegalStateException("Falta " + PATH);
            JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject cap = root.getAsJsonObject("capacity");
            for (Map.Entry<String, JsonElement> e : cap.entrySet()) {
                if (e.getKey().equals("default")) defaultCapacity = e.getValue().getAsInt();
                else c.put(e.getKey(), e.getValue().getAsInt());
            }
            if (root.has("caps")) {
                Map<String, Double> cp = new LinkedHashMap<>();
                for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("caps").entrySet()) cp.put(e.getKey(), e.getValue().getAsDouble());
                caps = cp;
            }
            if (root.has("loot")) {
                JsonObject lo = root.getAsJsonObject("loot");
                if (lo.has("default")) lootDefault = parseTier(lo.getAsJsonObject("default"), lootDefault, "");
                List<LootTier> tiers = new ArrayList<>();
                if (lo.has("tiers")) {
                    for (JsonElement t : lo.getAsJsonArray("tiers")) {
                        JsonObject to = t.getAsJsonObject();
                        tiers.add(parseTier(to, lootDefault, to.get("match").getAsString()));
                    }
                }
                lootTiers = tiers;
            }
            if (root.has("forge")) {
                JsonObject f = root.getAsJsonObject("forge");
                forgeRules = new ForgeRules(
                        !f.has("sameQualityPromotes") || f.get("sameQualityPromotes").getAsBoolean(),
                        !f.has("higherReplaces") || f.get("higherReplaces").getAsBoolean(),
                        Math.max(0, Math.min(Quality.values().length - 1,
                                f.has("maxQuality") ? f.get("maxQuality").getAsInt() : Quality.values().length - 1)),
                        Math.max(0, Math.min(Quality.values().length - 1,
                                f.has("fusionMaxQuality") ? f.get("fusionMaxQuality").getAsInt() : 3)));
            }
            for (JsonElement el : root.getAsJsonArray("runes")) {
                JsonObject o = el.getAsJsonObject();
                JsonArray vals = o.getAsJsonArray("values");
                double[] values = new double[vals.size()];
                for (int i = 0; i < values.length; i++) values[i] = vals.get(i).getAsDouble();
                Set<String> targets = new LinkedHashSet<>();
                for (JsonElement t : o.getAsJsonArray("targets")) targets.add(t.getAsString());
                String id = o.get("id").getAsString();
                r.put(id, new RuneDef(id, o.get("cost").getAsInt(), o.get("effect").getAsString(), values, targets,
                        o.has("weight") ? o.get("weight").getAsInt() : 1));
            }
        } catch (java.io.IOException e) {
            throw new IllegalStateException("No se pudo leer " + PATH, e);
        }
        capacity = c;
        runes = r;
    }

    private static LootTier parseTier(JsonObject o, LootTier base, String match) {
        int[] w = base.weights();
        if (o.has("weights")) {
            JsonArray a = o.getAsJsonArray("weights");
            w = new int[a.size()];
            for (int i = 0; i < w.length; i++) w[i] = a.get(i).getAsInt();
        }
        return new LootTier(match,
                o.has("chancePercent") ? o.get("chancePercent").getAsDouble() : base.chancePercent(),
                o.has("rolls") ? o.get("rolls").getAsInt() : base.rolls(), w);
    }

    /** Tope total (suma de todo el equipo) de un efecto; sin tope = infinito. */
    public static double cap(String effect) {
        load();
        return caps.getOrDefault(effect, Double.MAX_VALUE);
    }

    /** Regla de loot para una tabla (por su ruta, p. ej. "chests/end_city_treasure"): la primera cuyo "match" aparezca; si no, la general. */
    public static LootTier lootTierFor(String tablePath) {
        load();
        for (LootTier t : lootTiers) if (tablePath.contains(t.match())) return t;
        return lootDefault;
    }

    public static RuneDef get(String id) {
        load();
        return runes.get(id);
    }

    public static Collection<RuneDef> all() {
        load();
        return runes.values();
    }

    public static Set<String> ids() {
        load();
        return runes.keySet();
    }

    /** Capacidad por material (prefijo del id del objeto: iron_sword -> iron). */
    public static Map<String, Integer> capacityByMaterial() {
        load();
        return capacity;
    }

    public static ForgeRules forge() {
        load();
        return forgeRules;
    }

    public static int defaultCapacity() {
        load();
        return defaultCapacity;
    }
}
