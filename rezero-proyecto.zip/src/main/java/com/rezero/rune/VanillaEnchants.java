package com.rezero.rune;

import com.rezero.Config;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.village.VillagerTradesEvent;

/**
 * Elimina por completo los encantamientos de Minecraft (se puede apagar con removeVanillaEnchantments en la config):
 * libros encantados (loot, trueques, creativo), encantamientos en cualquier objeto o mob, y la mesa de encantamientos.
 * El yunque ya es la Forja Runica (ver {@link ForgeEvents}), asi que tampoco hay costes de nivel.
 */
public final class VanillaEnchants {
    private VanillaEnchants() {}

    public static void register() {
        NeoForge.EVENT_BUS.addListener(VanillaEnchants::onPlayerTick);
        NeoForge.EVENT_BUS.addListener(VanillaEnchants::onEntityJoin);
        NeoForge.EVENT_BUS.addListener(VanillaEnchants::onRightClickBlock);
        NeoForge.EVENT_BUS.addListener(VanillaEnchants::onVillagerTrades);
    }

    public static boolean enabled() {
        return Config.REMOVE_VANILLA_ENCHANTS.get();
    }

    private static boolean hasEnchants(ItemStack s) {
        ItemEnchantments e = s.get(DataComponents.ENCHANTMENTS);
        ItemEnchantments st = s.get(DataComponents.STORED_ENCHANTMENTS);
        return (e != null && !e.isEmpty()) || (st != null && !st.isEmpty());
    }

    /** Quita los encantamientos. Un libro encantado pasa a ser un libro normal. Devuelve el objeto resultante. */
    public static ItemStack sanitize(ItemStack stack) {
        if (stack.isEmpty()) return stack;
        if (stack.is(Items.ENCHANTED_BOOK)) return new ItemStack(Items.BOOK, stack.getCount());
        if (hasEnchants(stack)) {
            stack.remove(DataComponents.ENCHANTMENTS);
            stack.remove(DataComponents.STORED_ENCHANTMENTS);
        }
        return stack;
    }

    /** Cada segundo limpia el inventario (cubre trueques, comandos, cofres antiguos...). */
    private static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer p) || !enabled() || p.tickCount % 20 != 0) return;
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            ItemStack r = sanitize(s);
            if (r != s) inv.setItem(i, r);
        }
    }

    /** Mobs con equipo encantado (zombies con espada, etc.) lo pierden al aparecer. */
    private static void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide || !enabled() || !(event.getEntity() instanceof Mob mob)) return;
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            ItemStack s = mob.getItemBySlot(slot);
            if (!s.isEmpty() && hasEnchants(s)) mob.setItemSlot(slot, sanitize(s));
        }
    }

    /** La mesa de encantamientos ya no se abre. */
    private static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!enabled() || !event.getLevel().getBlockState(event.getPos()).is(Blocks.ENCHANTING_TABLE)) return;
        event.setCanceled(true);
        event.setCancellationResult(net.minecraft.world.InteractionResult.sidedSuccess(event.getLevel().isClientSide));
        if (!event.getLevel().isClientSide) {
            event.getEntity().displayClientMessage(Component.translatable("message.rezero.enchanting_disabled"), true);
        }
    }

    /** Los aldeanos dejan de vender libros y objetos encantados. */
    private static void onVillagerTrades(VillagerTradesEvent event) {
        if (!enabled()) return;
        for (var list : event.getTrades().values()) {
            try {
                list.removeIf(l -> l.getClass().getSimpleName().startsWith("Enchant"));
            } catch (UnsupportedOperationException ignored) {
                // lista inmutable: el inventario se limpia igualmente cada segundo
            }
        }
    }

    /** Fuera libros encantados del modo creativo (se registra en el bus del mod). */
    public static void onCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (!enabled()) return;
        for (ItemStack s : new ArrayList<>(event.getParentEntries())) {
            if (s.is(Items.ENCHANTED_BOOK) || hasEnchants(s)) event.remove(s, CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS);
        }
        for (ItemStack s : new ArrayList<>(event.getSearchEntries())) {
            if (s.is(Items.ENCHANTED_BOOK) || hasEnchants(s)) event.remove(s, CreativeModeTab.TabVisibility.SEARCH_TAB_ONLY);
        }
    }
}
