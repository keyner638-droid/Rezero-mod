package com.rezero.rune;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;

/**
 * Generacion de runas para los cofres. Probabilidades, tiradas y pesos por calidad estan en runes.json ("loot"):
 * la primera regla cuyo "match" aparezca en el id de la tabla (p. ej. "end_city") manda; si no, la general.
 * Calidad Divina: peso 0 en todas partes (reservada para algo especial; sube su peso en el json cuando quieras).
 */
public final class RuneLoot {
    private RuneLoot() {}

    /** Runas extra para un cofre con esa tabla de loot (vacio si no toca). */
    public static List<ItemStack> roll(String tablePath, RandomSource random) {
        List<ItemStack> out = new ArrayList<>();
        RuneRegistry.LootTier tier = RuneRegistry.lootTierFor(tablePath);
        if (tier.chancePercent() <= 0.0 || RuneRegistry.all().isEmpty()) return out;
        if (random.nextDouble() * 100.0 >= tier.chancePercent()) return out;
        for (int i = 0; i < Math.max(1, tier.rolls()); i++) {
            RuneDef def = pickRune(random);
            int q = pickQuality(tier.weights(), random);
            if (def != null && q >= 0) out.add(RuneItem.create(def.id(), Quality.byIndex(q)));
        }
        return out;
    }

    private static RuneDef pickRune(RandomSource random) {
        int total = 0;
        for (RuneDef d : RuneRegistry.all()) total += Math.max(0, d.weight());
        if (total <= 0) return null;
        int r = random.nextInt(total);
        for (RuneDef d : RuneRegistry.all()) {
            r -= Math.max(0, d.weight());
            if (r < 0) return d;
        }
        return null;
    }

    /** Indice de calidad segun pesos, o -1 si todos son 0. */
    private static int pickQuality(int[] weights, RandomSource random) {
        int total = 0;
        for (int w : weights) total += Math.max(0, w);
        if (total <= 0) return -1;
        int r = random.nextInt(total);
        for (int i = 0; i < weights.length; i++) {
            r -= Math.max(0, weights[i]);
            if (r < 0) return i;
        }
        return -1;
    }
}
