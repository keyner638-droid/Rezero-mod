package com.rezero.rune;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/** Una runa concreta (tipo + calidad) guardada en un objeto. */
public record RuneInstance(String id, int quality) {
    public static final Codec<RuneInstance> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.STRING.fieldOf("id").forGetter(RuneInstance::id),
            Codec.INT.fieldOf("quality").forGetter(RuneInstance::quality)
    ).apply(i, RuneInstance::new));

    public static final StreamCodec<ByteBuf, RuneInstance> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.STRING_UTF8, RuneInstance::id,
            ByteBufCodecs.VAR_INT, RuneInstance::quality,
            RuneInstance::new);

    public Quality qualityEnum() {
        return Quality.byIndex(quality);
    }
}
