package com.rezero.rune;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.item.ItemStack;

/**
 * Logica de la Forja Runica (sin interfaz). Dado el objeto de la casilla 1 y la runa de la casilla 2 calcula que pasaria:
 * incrustar, mejorar una runa que ya esta en el objeto, reemplazarla por una mejor, o fusionar dos runas entre si.
 * Las reglas de mejora salen de runes.json ("forge"), asi que se pueden cambiar sin tocar codigo.
 */
public final class RuneForge {
    private RuneForge() {}

    public enum Status {
        EMPTY(false), NEED_RUNE(false), NEED_ITEM(false), INVALID_ITEM(false), INVALID_RUNE(false),
        NOT_COMPATIBLE(false), NO_CAPACITY(false), MAX_QUALITY(false), FUSION_CAP(false), LOWER_QUALITY(false), FUSE_MISMATCH(false),
        OK_INSERT(true), OK_UPGRADE(true), OK_REPLACE(true), OK_FUSE(true);

        private final boolean ok;

        Status(boolean ok) {
            this.ok = ok;
        }

        public boolean ok() {
            return ok;
        }

        /** Clave del lang con el mensaje para el jugador. */
        public String langKey() {
            return "rune.rezero.forge.status." + name().toLowerCase(java.util.Locale.ROOT);
        }
    }

    /**
     * Resultado calculado.
     * rune = la runa de la casilla de runa; before = la runa que ya habia (en el objeto o en la casilla 1) o null;
     * after = la runa que quedaria; max/used/usedAfter = capacidad del objeto (max 0 si no hay objeto con capacidad).
     */
    public record Preview(Status status, ItemStack result, RuneInstance rune, RuneInstance before, RuneInstance after,
                          int max, int used, int usedAfter) {
        public boolean ok() {
            return status.ok();
        }
    }

    private static Preview fail(Status s, RuneInstance rune, RuneInstance after, int max, int used) {
        return new Preview(s, ItemStack.EMPTY, rune, null, after, max, used, used);
    }

    public static boolean isRune(ItemStack stack) {
        return stack.getItem() instanceof RuneItem && stack.has(RuneComponents.RUNE.get());
    }

    public static boolean isEquipment(ItemStack stack) {
        return !RuneLogic.categories(stack).isEmpty();
    }

    private static int maxQuality() {
        return RuneRegistry.forge().maxQuality();
    }

    public static Preview preview(ItemStack target, ItemStack runeStack) {
        if (runeStack.isEmpty()) {
            return fail(target.isEmpty() ? Status.EMPTY : Status.NEED_RUNE, null, null, 0, 0);
        }
        RuneInstance rune = isRune(runeStack) ? runeStack.get(RuneComponents.RUNE.get()) : null;
        RuneDef def = rune == null ? null : RuneRegistry.get(rune.id());
        if (def == null) return fail(Status.INVALID_RUNE, rune, rune, 0, 0);
        if (target.isEmpty()) return fail(Status.NEED_ITEM, rune, rune, 0, 0);

        if (isRune(target)) return previewFuse(target, rune);
        if (!isEquipment(target)) return fail(Status.INVALID_ITEM, rune, rune, 0, 0);

        int max = RuneLogic.maxCapacity(target);
        int used = RuneLogic.usedCapacity(target);
        if (!RuneLogic.isCompatible(def, target)) return fail(Status.NOT_COMPATIBLE, rune, rune, max, used);

        List<RuneInstance> cur = RuneLogic.runesOf(target);
        int idx = -1;
        for (int i = 0; i < cur.size(); i++) {
            if (cur.get(i).id().equals(rune.id())) {
                idx = i;
                break;
            }
        }

        if (idx < 0) {
            if (used + def.cost() > max) return fail(Status.NO_CAPACITY, rune, rune, max, used);
            List<RuneInstance> next = new ArrayList<>(cur);
            next.add(rune);
            return ok(Status.OK_INSERT, target, next, rune, null, rune, max, used, used + def.cost());
        }

        // Ya hay una runa de este tipo en el objeto: mismo coste de capacidad, solo cambia su calidad.
        RuneInstance existing = cur.get(idx);
        RuneInstance after;
        Status st;
        if (rune.quality() == existing.quality()) {
            if (existing.quality() >= maxQuality()) return fail(Status.MAX_QUALITY, rune, existing, max, used);
            if (existing.quality() >= RuneRegistry.forge().fusionMaxQuality()) return fail(Status.FUSION_CAP, rune, existing, max, used);
            if (!RuneRegistry.forge().sameQualityPromotes()) return fail(Status.LOWER_QUALITY, rune, existing, max, used);
            after = new RuneInstance(rune.id(), existing.quality() + 1);
            st = Status.OK_UPGRADE;
        } else if (rune.quality() > existing.quality()) {
            if (!RuneRegistry.forge().higherReplaces()) return fail(Status.LOWER_QUALITY, rune, existing, max, used);
            after = new RuneInstance(rune.id(), Math.min(rune.quality(), maxQuality()));
            st = Status.OK_REPLACE;
        } else {
            return fail(Status.LOWER_QUALITY, rune, existing, max, used);
        }
        List<RuneInstance> next = new ArrayList<>(cur);
        next.set(idx, after);
        return ok(st, target, next, rune, existing, after, max, used, used);
    }

    /** Runa en la casilla del objeto + runa en la casilla de runa: dos iguales (tipo y calidad) dan una de calidad superior. */
    private static Preview previewFuse(ItemStack target, RuneInstance rune) {
        RuneInstance base = target.get(RuneComponents.RUNE.get());
        if (base == null || RuneRegistry.get(base.id()) == null) return fail(Status.INVALID_RUNE, rune, rune, 0, 0);
        if (!RuneRegistry.forge().sameQualityPromotes() || !base.id().equals(rune.id()) || base.quality() != rune.quality()) {
            return fail(Status.FUSE_MISMATCH, rune, rune, 0, 0);
        }
        if (base.quality() >= maxQuality()) return fail(Status.MAX_QUALITY, rune, base, 0, 0);
        if (base.quality() >= RuneRegistry.forge().fusionMaxQuality()) return fail(Status.FUSION_CAP, rune, base, 0, 0);
        RuneInstance after = new RuneInstance(base.id(), base.quality() + 1);
        ItemStack result = new ItemStack(target.getItem());
        result.set(RuneComponents.RUNE.get(), after);
        return new Preview(Status.OK_FUSE, result, rune, base, after, 0, 0, 0);
    }

    private static Preview ok(Status st, ItemStack target, List<RuneInstance> runes, RuneInstance rune,
                              RuneInstance before, RuneInstance after, int max, int used, int usedAfter) {
        ItemStack result = target.copy();
        result.setCount(1);
        result.set(RuneComponents.RUNES.get(), List.copyOf(runes));
        return new Preview(st, result, rune, before, after, max, used, usedAfter);
    }
}
