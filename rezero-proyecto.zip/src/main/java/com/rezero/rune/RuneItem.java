package com.rezero.rune;

import com.rezero.ModItems;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/** UNA sola runa-objeto; el tipo y la calidad viajan en el componente RUNE. */
public class RuneItem extends Item {
    public RuneItem(Properties props) {
        super(props);
    }

    public static ItemStack create(String id, Quality quality) {
        ItemStack s = new ItemStack(ModItems.RUNE.get());
        s.set(RuneComponents.RUNE.get(), new RuneInstance(id, quality.ordinal()));
        return s;
    }

    @Override
    public Component getName(ItemStack stack) {
        RuneInstance r = stack.get(RuneComponents.RUNE.get());
        if (r == null) return super.getName(stack);
        return Component.translatable("rune.rezero." + r.id())
                .withStyle(Style.EMPTY.withColor(r.qualityEnum().color()))
                .append(" (").append(r.qualityEnum().displayName()).append(")");
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
        RuneInstance r = stack.get(RuneComponents.RUNE.get());
        RuneDef def = r == null ? null : RuneRegistry.get(r.id());
        if (def == null) return;
        Quality q = r.qualityEnum();
        tooltip.add(Component.translatable("rune.rezero.quality").withStyle(ChatFormatting.GRAY)
                .append(q.displayName()));
        tooltip.add(def.description(q).copy().withStyle(ChatFormatting.GREEN));
        tooltip.add(Component.translatable("rune.rezero.cost", def.cost()).withStyle(ChatFormatting.GRAY));
    }
}
