package com.rezero.rune;

import com.rezero.ReZero;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.damagesource.DamageContainer;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Efectos de las runas. Cada runa de runes.json trae un "effect" (texto); aqui se aplica por ese texto, asi que
 * anadir una runa nueva con un efecto que ya existe NO requiere codigo. Un efecto nuevo = una constante + un hook aqui.
 * Los valores salen de la calidad de cada runa y se suman entre todo el equipo hasta el tope ("caps" en runes.json).
 *
 *  - Mano principal: damage_percent, armor_pierce_percent, life_steal_percent, ignite/slow_chance_percent,
 *    attack_speed_percent, loot_percent (ver {@link RuneLootModifier}).
 *  - Armadura puesta: damage_reduction_percent, move_speed_percent.
 *  - magic_power_percent: armadura + mano principal + mano secundaria (potencia las armas magicas, ver {@link #magicMultiplier}).
 */
public final class RuneEffects {
    public static final String DAMAGE = "damage_percent";
    public static final String REDUCTION = "damage_reduction_percent";
    public static final String LOOT = "loot_percent";
    public static final String MOVE_SPEED = "move_speed_percent";
    public static final String MAGIC = "magic_power_percent";
    public static final String IGNITE = "ignite_chance_percent";
    public static final String SLOW = "slow_chance_percent";
    public static final String ATTACK_SPEED = "attack_speed_percent";
    public static final String PIERCE = "armor_pierce_percent";
    public static final String LIFE_STEAL = "life_steal_percent";

    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final ResourceLocation MOVE_ID = ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "rune_move_speed");
    private static final ResourceLocation ATTACK_SPEED_ID = ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "rune_attack_speed");

    private RuneEffects() {}

    public static void register() {
        NeoForge.EVENT_BUS.addListener(RuneEffects::onIncomingDamage);
        NeoForge.EVENT_BUS.addListener(RuneEffects::onDamagePre);
        NeoForge.EVENT_BUS.addListener(RuneEffects::onDamagePost);
        NeoForge.EVENT_BUS.addListener(RuneEffects::onPlayerTick);
    }

    // ---- sumas ----

    /** Suma del efecto en un objeto (sin tope). */
    public static double sum(ItemStack stack, String effect) {
        double total = 0.0;
        for (RuneInstance r : RuneLogic.runesOf(stack)) {
            RuneDef d = RuneRegistry.get(r.id());
            if (d != null && d.effect().equals(effect)) total += d.value(r.qualityEnum());
        }
        return total;
    }

    private static double capped(String effect, double v) {
        return Math.min(v, RuneRegistry.cap(effect));
    }

    public static double held(LivingEntity e, String effect) {
        return capped(effect, sum(e.getMainHandItem(), effect));
    }

    public static double worn(LivingEntity e, String effect) {
        double t = 0.0;
        for (EquipmentSlot s : ARMOR) t += sum(e.getItemBySlot(s), effect);
        return capped(effect, t);
    }

    /** Multiplicador de dano de las armas magicas (varita): 1 + poder magico/100. */
    public static double magicMultiplier(LivingEntity e) {
        double t = sum(e.getMainHandItem(), MAGIC) + sum(e.getOffhandItem(), MAGIC);
        for (EquipmentSlot s : ARMOR) t += sum(e.getItemBySlot(s), MAGIC);
        return 1.0 + capped(MAGIC, t) / 100.0;
    }

    // ---- dano ----

    /** Poder (+% dano del atacante) y Proteccion (-% dano del que recibe). */
    private static void onIncomingDamage(LivingIncomingDamageEvent event) {
        DamageSource src = event.getSource();
        float original = event.getAmount();
        float amount = original;
        if (src.getEntity() instanceof LivingEntity attacker) {
            double power = held(attacker, DAMAGE);
            if (power > 0.0) amount *= 1.0f + (float) (power / 100.0);
        }
        if (!src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            double prot = worn(event.getEntity(), REDUCTION);
            if (prot > 0.0) amount *= 1.0f - (float) (prot / 100.0);
        }
        if (amount != original) event.setAmount(amount);
    }

    /** Vacio: devuelve parte del dano que la armadura habria absorbido. */
    private static void onDamagePre(LivingDamageEvent.Pre event) {
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker)) return;
        double pierce = held(attacker, PIERCE);
        if (pierce <= 0.0) return;
        float absorbed = event.getContainer().getReduction(DamageContainer.Reduction.ARMOR);
        if (absorbed > 0.0f) event.setNewDamage(event.getNewDamage() + absorbed * (float) (pierce / 100.0));
    }

    /** Vampirismo, Fuego y Hielo: despues de que el golpe haya hecho dano de verdad. */
    private static void onDamagePost(LivingDamageEvent.Post event) {
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker) || attacker == event.getEntity()) return;
        if (attacker.level().isClientSide) return;
        LivingEntity target = event.getEntity();
        float dealt = event.getNewDamage();
        if (dealt <= 0.0f) return;

        double steal = held(attacker, LIFE_STEAL);
        if (steal > 0.0) attacker.heal(dealt * (float) (steal / 100.0));

        double ignite = held(attacker, IGNITE);
        if (ignite > 0.0 && !target.fireImmune() && attacker.getRandom().nextDouble() * 100.0 < ignite) {
            target.setRemainingFireTicks(Math.max(target.getRemainingFireTicks(), 80));
        }
        double slow = held(attacker, SLOW);
        if (slow > 0.0 && attacker.getRandom().nextDouble() * 100.0 < slow) {
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1), attacker);
        }
    }

    // ---- atributos (Agilidad y Viento) ----

    private static void onPlayerTick(PlayerTickEvent.Post event) {
        Player p = event.getEntity();
        if (p.level().isClientSide || p.tickCount % 5 != 0) return;
        setModifier(p, Attributes.MOVEMENT_SPEED, MOVE_ID, worn(p, MOVE_SPEED) / 100.0);
        setModifier(p, Attributes.ATTACK_SPEED, ATTACK_SPEED_ID, held(p, ATTACK_SPEED) / 100.0);
    }

    private static void setModifier(Player p, Holder<Attribute> attr, ResourceLocation id, double amount) {
        AttributeInstance inst = p.getAttribute(attr);
        if (inst == null) return;
        AttributeModifier cur = inst.getModifier(id);
        if (amount <= 0.0) {
            if (cur != null) inst.removeModifier(id);
            return;
        }
        if (cur != null && cur.amount() == amount) return;
        inst.addOrUpdateTransientModifier(new AttributeModifier(id, amount, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
    }
}
