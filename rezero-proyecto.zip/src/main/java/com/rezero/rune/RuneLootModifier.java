package com.rezero.rune;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.neoforged.neoforge.common.loot.IGlobalLootModifier;
import net.neoforged.neoforge.common.loot.LootModifier;

/**
 * Un unico modificador global de loot (data/rezero/loot_modifiers/rune_loot.json) que hace tres cosas, cada una en su clase:
 * 1) quita encantamientos del loot ({@link VanillaEnchants}), 2) mete runas en los cofres ({@link RuneLoot}),
 * 3) aplica Fortuna al botin de bloques y mobs ({@link RuneEffects#LOOT}).
 */
public class RuneLootModifier extends LootModifier {
    public static final MapCodec<RuneLootModifier> CODEC =
            RecordCodecBuilder.mapCodec(inst -> codecStart(inst).apply(inst, RuneLootModifier::new));

    public RuneLootModifier(LootItemCondition[] conditions) {
        super(conditions);
    }

    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot, LootContext context) {
        // 1) sin encantamientos
        if (VanillaEnchants.enabled()) {
            for (int i = 0; i < loot.size(); i++) loot.set(i, VanillaEnchants.sanitize(loot.get(i)));
        }

        String path = context.getQueriedLootTableId().getPath();
        if (path.startsWith("chests/")) {
            // 2) runas en cofres
            loot.addAll(RuneLoot.roll(path, context.getRandom()));
        } else {
            // 3) Fortuna: probabilidad de duplicar cada objeto del botin
            ItemStack tool = context.getParamOrNull(LootContextParams.TOOL);
            double fortune = 0.0;
            if (tool != null) {
                fortune = Math.min(RuneEffects.sum(tool, RuneEffects.LOOT), RuneRegistry.cap(RuneEffects.LOOT));
            } else if (context.getParamOrNull(LootContextParams.ATTACKING_ENTITY) instanceof LivingEntity killer) {
                fortune = RuneEffects.held(killer, RuneEffects.LOOT);
            }
            if (fortune > 0.0) {
                for (ItemStack s : loot) {
                    if (RuneForge.isRune(s)) continue;
                    if (context.getRandom().nextDouble() * 100.0 < fortune) {
                        s.setCount(Math.min(s.getMaxStackSize(), s.getCount() * 2));
                    }
                }
            }
        }
        return loot;
    }

    @Override
    public MapCodec<? extends IGlobalLootModifier> codec() {
        return CODEC;
    }
}
