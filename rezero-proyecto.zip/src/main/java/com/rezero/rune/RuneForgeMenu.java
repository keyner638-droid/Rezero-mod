package com.rezero.rune;

import com.rezero.ModMenus;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/**
 * Menu de la Forja Runica (el yunque vanilla). Casillas: 0 = objeto (o runa a fusionar), 1 = runa, 2 = resultado
 * (solo se ve, no se puede coger). El boton "Forjar" (id 0) confirma. Todo el calculo esta en {@link RuneForge}.
 */
public class RuneForgeMenu extends AbstractContainerMenu {
    public static final int SLOT_ITEM = 0;
    public static final int SLOT_RUNE = 1;
    public static final int SLOT_RESULT = 2;
    public static final int BUTTON_CONFIRM = 0;

    private static final int INV_START = 3;
    private static final int INV_END = INV_START + 36;

    private final Container input = new SimpleContainer(2) {
        @Override
        public void setChanged() {
            super.setChanged();
            RuneForgeMenu.this.slotsChanged(this);
        }
    };
    private final Container result = new SimpleContainer(1);
    private final ContainerLevelAccess access;

    /** Lado cliente. */
    public RuneForgeMenu(int id, Inventory inv) {
        this(id, inv, ContainerLevelAccess.NULL);
    }

    public RuneForgeMenu(int id, Inventory inv, ContainerLevelAccess access) {
        super(ModMenus.RUNE_FORGE.get(), id);
        this.access = access;

        addSlot(new Slot(input, 0, 10, 18) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return RuneForge.isRune(stack) || RuneForge.isEquipment(stack);
            }

            @Override
            public int getMaxStackSize() {
                return 1;
            }
        });
        addSlot(new Slot(input, 1, 48, 18) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return RuneForge.isRune(stack);
            }
        });
        addSlot(new Slot(result, 0, 86, 18) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return false;
            }

            @Override
            public boolean mayPickup(Player player) {
                return false;
            }
        });

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inv, col + row * 9 + 9, 8 + col * 18, 134 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inv, col, 8 + col * 18, 192));
        }
    }

    public ItemStack targetStack() {
        return input.getItem(0);
    }

    public ItemStack runeStack() {
        return input.getItem(1);
    }

    @Override
    public void slotsChanged(Container container) {
        super.slotsChanged(container);
        if (container == input) {
            RuneForge.Preview p = RuneForge.preview(input.getItem(0), input.getItem(1));
            result.setItem(0, p.ok() ? p.result().copy() : ItemStack.EMPTY);
        }
    }

    /** Boton "Forjar": aplica el resultado (solo servidor) y gasta una runa. */
    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (id != BUTTON_CONFIRM) return false;
        RuneForge.Preview p = RuneForge.preview(input.getItem(0), input.getItem(1));
        if (!p.ok()) return false;

        ItemStack rune = input.getItem(1).copy();
        rune.shrink(1);
        input.setItem(1, rune.isEmpty() ? ItemStack.EMPTY : rune);
        input.setItem(0, p.result().copy()); // al final, para que el resultado se recalcule con el estado definitivo

        access.execute((level, pos) -> {
            level.playSound(null, pos, SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 0.6f, 1.1f);
            level.playSound(null, pos, SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.BLOCKS, 1.0f, 1.2f);
        });
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = slots.get(index);
        if (slot == null || !slot.hasItem() || index == SLOT_RESULT) return ItemStack.EMPTY;
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();

        if (index < INV_START) {
            if (!moveItemStackTo(stack, INV_START, INV_END, true)) return ItemStack.EMPTY;
        } else if (RuneForge.isRune(stack)) {
            // primero la casilla de runa; si ya esta ocupada, la del objeto (para fusionar dos runas)
            int dest = !slots.get(SLOT_RUNE).hasItem() ? SLOT_RUNE : (!slots.get(SLOT_ITEM).hasItem() ? SLOT_ITEM : -1);
            if (dest < 0 || !moveItemStackTo(stack, dest, dest + 1, false)) return ItemStack.EMPTY;
        } else if (RuneForge.isEquipment(stack)) {
            if (!moveItemStackTo(stack, SLOT_ITEM, SLOT_ITEM + 1, false)) return ItemStack.EMPTY;
        } else {
            return ItemStack.EMPTY;
        }

        if (stack.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
        else slot.setChanged();
        if (stack.getCount() == original.getCount()) return ItemStack.EMPTY;
        slot.onTake(player, stack);
        return original;
    }

    @Override
    public boolean stillValid(Player player) {
        return access.evaluate((level, pos) -> level.getBlockState(pos).is(BlockTags.ANVIL)
                && player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0, true);
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        access.execute((level, pos) -> clearContainer(player, input));
    }
}
