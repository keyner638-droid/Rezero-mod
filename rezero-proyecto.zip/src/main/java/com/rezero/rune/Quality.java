package com.rezero.rune;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;

/** Calidades de una runa. El orden define la potencia (indice 0 = Comun ... 4 = Divina). */
public enum Quality {
    COMMON("common", 0xFFFFFF),
    RARE("rare", 0x55AAFF),
    EPIC("epic", 0xB266FF),
    LEGENDARY("legendary", 0xFFAA00),
    DIVINE("divine", 0xFF5577);

    private final String key;
    private final int color;

    Quality(String key, int color) {
        this.key = key;
        this.color = color;
    }

    public int color() {
        return color;
    }

    public Component displayName() {
        return Component.translatable("quality.rezero." + key).withStyle(Style.EMPTY.withColor(color));
    }

    public static Quality byIndex(int i) {
        Quality[] v = values();
        return v[Math.max(0, Math.min(v.length - 1, i))];
    }
}
