package com.rezero.rune;

import com.rezero.ReZero;
import java.util.List;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Componentes de datos: RUNE (la runa-objeto) y RUNES (runas incrustadas en un arma/herramienta/armadura). */
public final class RuneComponents {
    public static final DeferredRegister<DataComponentType<?>> COMPONENTS =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, ReZero.MODID);

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<RuneInstance>> RUNE =
            COMPONENTS.register("rune", () -> DataComponentType.<RuneInstance>builder()
                    .persistent(RuneInstance.CODEC)
                    .networkSynchronized(RuneInstance.STREAM_CODEC)
                    .build());

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<List<RuneInstance>>> RUNES =
            COMPONENTS.register("runes", () -> DataComponentType.<List<RuneInstance>>builder()
                    .persistent(RuneInstance.CODEC.listOf())
                    .networkSynchronized(RuneInstance.STREAM_CODEC.apply(ByteBufCodecs.list()))
                    .build());

    private RuneComponents() {}
}
