package com.rezero.rune;

import java.util.Locale;
import java.util.Set;
import net.minecraft.network.chat.Component;

/** Definicion de una runa, leida de runes.json. Nombre y descripcion salen del lang (rune.rezero.<id>[.desc]). */
/** weight = probabilidad relativa de salir en cofres (1 por defecto). */
public record RuneDef(String id, int cost, String effect, double[] values, Set<String> targets, int weight) {

    public double value(Quality q) {
        return values[Math.min(q.ordinal(), values.length - 1)];
    }

    public Component name() {
        return Component.translatable("rune.rezero." + id);
    }

    public Component description(Quality q) {
        double v = value(q);
        String s = v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.ROOT, "%.1f", v);
        return Component.translatable("rune.rezero." + id + ".desc", s);
    }
}
