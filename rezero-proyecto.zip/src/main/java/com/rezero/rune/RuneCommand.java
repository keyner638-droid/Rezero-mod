package com.rezero.rune;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/** Comando de pruebas: /runa <id> <calidad 0-4> incrusta la runa en el objeto de la mano principal (OP). */
public final class RuneCommand {
    private RuneCommand() {}

    public static void register() {
        NeoForge.EVENT_BUS.addListener(RuneCommand::onRegister);
    }

    private static void onRegister(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("runa")
                .requires(s -> s.hasPermission(2))
                .then(Commands.argument("id", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(RuneRegistry.ids(), b))
                        .then(Commands.argument("calidad", IntegerArgumentType.integer(0, 4))
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    String id = StringArgumentType.getString(ctx, "id");
                                    int q = IntegerArgumentType.getInteger(ctx, "calidad");
                                    ItemStack held = p.getMainHandItem();
                                    if (RuneRegistry.get(id) == null) {
                                        ctx.getSource().sendFailure(Component.literal("Runa desconocida: " + id));
                                        return 0;
                                    }
                                    RuneLogic.Result res = RuneLogic.add(held, new RuneInstance(id, q));
                                    if (res == RuneLogic.Result.OK) {
                                        ctx.getSource().sendSuccess(() -> Component.literal("Runa incrustada."), false);
                                        return Command.SINGLE_SUCCESS;
                                    }
                                    ctx.getSource().sendFailure(Component.literal("No se pudo: " + res));
                                    return 0;
                                }))));
    }
}
