package com.rezero.rune;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TridentItem;

/** Reglas: categoria del objeto, capacidad rúnica y insercion. La Forja ({@link RuneForge}) decide que hacer; {@link #add} es la insercion simple (la usa tambien /runa). */
public final class RuneLogic {
    private RuneLogic() {}

    public enum Result { OK, NOT_EQUIPMENT, NOT_COMPATIBLE, NO_CAPACITY, DUPLICATE }

    /** Categorias del objeto: weapon, tool, armor. Vacio = no admite runas. */
    public static Set<String> categories(ItemStack stack) {
        Set<String> s = new HashSet<>();
        var item = stack.getItem();
        if (item instanceof ArmorItem) s.add("armor");
        if (item instanceof SwordItem || item instanceof BowItem || item instanceof CrossbowItem
                || item instanceof TridentItem) s.add("weapon");
        if (item instanceof DiggerItem) {
            s.add("tool");
            if (BuiltInRegistries.ITEM.getKey(item).getPath().endsWith("_axe")) s.add("weapon");
        }
        return s;
    }

    public static int maxCapacity(ItemStack stack) {
        if (categories(stack).isEmpty()) return 0;
        String path = BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath();
        for (Map.Entry<String, Integer> e : RuneRegistry.capacityByMaterial().entrySet()) {
            if (path.startsWith(e.getKey() + "_")) return e.getValue();
        }
        return RuneRegistry.defaultCapacity();
    }

    public static List<RuneInstance> runesOf(ItemStack stack) {
        List<RuneInstance> l = stack.get(RuneComponents.RUNES.get());
        return l == null ? List.of() : l;
    }

    public static int usedCapacity(ItemStack stack) {
        int used = 0;
        for (RuneInstance r : runesOf(stack)) {
            RuneDef d = RuneRegistry.get(r.id());
            if (d != null) used += d.cost();
        }
        return used;
    }

    public static boolean isCompatible(RuneDef def, ItemStack stack) {
        for (String c : categories(stack)) if (def.targets().contains(c)) return true;
        return false;
    }

    /** Incrusta la runa si cabe. Una runa de cada tipo por objeto (mejorar/fusionar lo hace {@link RuneForge}). */
    public static Result add(ItemStack stack, RuneInstance rune) {
        RuneDef def = RuneRegistry.get(rune.id());
        if (def == null || categories(stack).isEmpty()) return Result.NOT_EQUIPMENT;
        if (!isCompatible(def, stack)) return Result.NOT_COMPATIBLE;
        List<RuneInstance> cur = runesOf(stack);
        for (RuneInstance r : cur) if (r.id().equals(rune.id())) return Result.DUPLICATE;
        if (usedCapacity(stack) + def.cost() > maxCapacity(stack)) return Result.NO_CAPACITY;
        List<RuneInstance> next = new ArrayList<>(cur);
        next.add(rune);
        stack.set(RuneComponents.RUNES.get(), List.copyOf(next));
        return Result.OK;
    }
}
