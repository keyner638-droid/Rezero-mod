package com.rezero;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.RandomSource;

/**
 * Las tres versiones del retorno. El servidor tira el dado y el cliente recibe cual toca.
 * {@code wakeSeconds}: segundos desde la muerte hasta que "se abren los ojos" (el servidor no avisa antes).
 */
public enum ReturnVariant {
    /** El sonido de siempre. */
    NORMAL(1.7f, 1.0f),
    /** El sonido de la temporada 4. */
    SEASON4(3.0f, 0.55f),
    /** I love you: pantalla totalmente negra mientras dura el audio (~22 s). */
    LOVE(22.3f, 1.0f);

    public final float wakeSeconds;
    public final float volume;

    ReturnVariant(float wakeSeconds, float volume) {
        this.wakeSeconds = wakeSeconds;
        this.volume = volume;
    }

    public SoundEvent sound() {
        return switch (this) {
            case NORMAL -> ModSounds.RETORNO.get();
            case SEASON4 -> ModSounds.RETORNO_S4.get();
            case LOVE -> ModSounds.I_LOVE_YOU.get();
        };
    }

    public static ReturnVariant byId(int id) {
        ReturnVariant[] all = values();
        return id >= 0 && id < all.length ? all[id] : NORMAL;
    }

    public static ReturnVariant roll(RandomSource random) {
        float r = random.nextFloat() * 100f;
        int love = Config.LOVE_CHANCE.get();
        if (r < love) return LOVE;
        if (r < love + Config.SEASON4_CHANCE.get()) return SEASON4;
        return NORMAL;
    }
}
