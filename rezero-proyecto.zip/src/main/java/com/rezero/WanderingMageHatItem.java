package com.rezero;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/**
 * Sombrero del Mago Errante (casco): +mana maxima y menos coste de mana en las armas mientras lo llevas puesto.
 * Los efectos se aplican en {@link Mana}; su modelo 3D puesto esta en client/WanderingMageHatModel.
 */
public class WanderingMageHatItem extends ArmorItem {
    public WanderingMageHatItem(Holder<ArmorMaterial> material, Properties properties) {
        super(material, Type.HELMET, properties);
    }

    public static boolean isWearing(Player player) {
        return player.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.WANDERING_MAGE_HAT.get());
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.rezero.wandering_mage_hat.mana", Config.HAT_MANA_BONUS.get())
                .withStyle(ChatFormatting.BLUE));
        tooltip.add(Component.translatable("item.rezero.wandering_mage_hat.cost", Config.HAT_COST_REDUCTION.get())
                .withStyle(ChatFormatting.BLUE));
    }
}
