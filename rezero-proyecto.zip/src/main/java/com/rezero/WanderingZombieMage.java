package com.rezero;

import javax.annotation.Nullable;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;

/**
 * Zombie Mago Errante: un zombie con tunica, sombrero y una linterna con una estrella.
 * Los drops estan en data/rezero/loot_table/entities/wandering_zombie_mage.json:
 * siempre una Estrella y un Pergamino, y 2% de soltar el Sombrero del Mago Errante.
 */
public class WanderingZombieMage extends Zombie {
    public WanderingZombieMage(EntityType<? extends WanderingZombieMage> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 24.0)
                .add(Attributes.MOVEMENT_SPEED, 0.22);
    }

    /** Nunca se convierte en Ahogado: si no, al nadar se perderia el mago (y sus drops). */
    @Override
    protected boolean convertsInWater() {
        return false;
    }

    /** Sin espadas/palas aleatorias en la mano. */
    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
    }

    /** Siempre adulto: el modelo con tunica y sombrero no esta pensado para bebes. */
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType,
                                        @Nullable SpawnGroupData spawnGroupData) {
        SpawnGroupData data = super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData);
        this.setBaby(false);
        return data;
    }

    /** Chispas doradas alrededor de la linterna (solo visual, en el cliente). */
    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide && this.isAlive() && this.random.nextInt(7) == 0) {
            double rad = Math.toRadians(this.yBodyRot);
            double fx = -Math.sin(rad), fz = Math.cos(rad);       // hacia delante
            double rx = -Math.cos(rad), rz = -Math.sin(rad);      // hacia su derecha
            double x = this.getX() + fx * 0.65 + rx * 0.4 + (this.random.nextDouble() - 0.5) * 0.4;
            double y = this.getY() + 0.7 + this.random.nextDouble() * 0.5;
            double z = this.getZ() + fz * 0.65 + rz * 0.4 + (this.random.nextDouble() - 0.5) * 0.4;
            this.level().addParticle(ParticleTypes.WAX_ON, x, y, z, 0.0, 0.02, 0.0);
        }
    }
}
