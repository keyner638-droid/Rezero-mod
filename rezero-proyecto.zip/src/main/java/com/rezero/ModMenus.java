package com.rezero;

import com.rezero.rune.RuneForgeMenu;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU, ReZero.MODID);

    /** Pantalla de la Forja Runica (el yunque vanilla). */
    public static final DeferredHolder<MenuType<?>, MenuType<RuneForgeMenu>> RUNE_FORGE =
            MENUS.register("rune_forge", () -> IMenuTypeExtension.<RuneForgeMenu>create((id, inv, buf) -> new RuneForgeMenu(id, inv)));

    private ModMenus() {}
}
