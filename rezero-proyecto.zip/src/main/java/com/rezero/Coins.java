package com.rezero;

import com.mojang.serialization.Codec;
import com.rezero.net.CoinsPayload;
import java.util.function.Supplier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/**
 * Economia: las monedas son un solo numero (total en cobre) guardado en el jugador.
 * 100 cobre = 1 plata, 100 plata = 1 oro. Se conserva al morir de verdad (copyOnDeath).
 */
public final class Coins {
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, ReZero.MODID);

    public static final Supplier<AttachmentType<Long>> COPPER = ATTACHMENTS.register("coins",
            () -> AttachmentType.builder(() -> 0L).serialize(Codec.LONG).copyOnDeath().build());

    /** XP total propia (no la de Minecraft). El nivel se deduce de este numero, ver {@link Levels}. */
    public static final Supplier<AttachmentType<Long>> XP = ATTACHMENTS.register("xp",
            () -> AttachmentType.builder(() -> 0L).serialize(Codec.LONG).copyOnDeath().build());

    /** Mana actual. Por defecto "infinito": se recorta a la mana maxima al leerla, asi el jugador nuevo empieza lleno. */
    public static final Supplier<AttachmentType<Integer>> MANA = ATTACHMENTS.register("mana",
            () -> AttachmentType.builder(() -> Integer.MAX_VALUE).serialize(Codec.INT).build());

    /** Cristales de mana consumidos. El bonus de mana se calcula a partir de este contador, nunca del maximo actual. */
    public static final Supplier<AttachmentType<Integer>> MANA_CRYSTALS = ATTACHMENTS.register("mana_crystals",
            () -> AttachmentType.builder(() -> 0).serialize(Codec.INT).copyOnDeath().build());

    /** Cristales de vida consumidos. El bonus de vida se calcula a partir de este contador, nunca de la vida maxima actual. */
    public static final Supplier<AttachmentType<Integer>> LIFE_CRYSTALS = ATTACHMENTS.register("life_crystals",
            () -> AttachmentType.builder(() -> 0).serialize(Codec.INT).copyOnDeath().build());

    /** Antiguo "mana maxima extra" (puntos). Solo se conserva para migrar partidas viejas a {@link #MANA_CRYSTALS}. */
    public static final Supplier<AttachmentType<Integer>> LEGACY_MANA_BONUS = ATTACHMENTS.register("mana_bonus",
            () -> AttachmentType.builder(() -> 0).serialize(Codec.INT).copyOnDeath().build());

    /** Antiguo "vida maxima extra" (puntos). Solo se conserva para migrar partidas viejas a {@link #LIFE_CRYSTALS}. */
    public static final Supplier<AttachmentType<Integer>> LEGACY_LIFE_BONUS = ATTACHMENTS.register("life_bonus",
            () -> AttachmentType.builder(() -> 0).serialize(Codec.INT).copyOnDeath().build());

    private Coins() {}

    public static long get(Player player) {
        return player.getData(COPPER);
    }

    public static void set(ServerPlayer player, long copper) {
        player.setData(COPPER, Math.max(0L, copper));
        sync(player);
    }

    public static void add(ServerPlayer player, long copper) {
        set(player, get(player) + copper);
    }

    /** Envia al cliente monedas, XP y mana. */
    public static void sync(ServerPlayer player) {
        PacketDistributor.sendToPlayer(player, new CoinsPayload(get(player), player.getData(XP), Mana.get(player), Mana.max(player)));
    }

    public static long gold(long copper) { return copper / 10000L; }
    public static long silver(long copper) { return (copper / 100L) % 100L; }
    public static long copperPart(long copper) { return copper % 100L; }
}
