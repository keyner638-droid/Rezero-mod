package com.rezero;

import com.mojang.serialization.Codec;
import com.rezero.net.CoinsPayload;
import java.util.function.Supplier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/**
 * Economia: las monedas son un solo numero (total en cobre) guardado en el jugador.
 * 100 cobre = 1 plata, 100 plata = 1 oro. Se conserva al morir de verdad (copyOnDeath).
 */
public final class Coins {
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, ReZero.MODID);

    public static final Supplier<AttachmentType<Long>> COPPER = ATTACHMENTS.register("coins",
            () -> AttachmentType.builder(() -> 0L).serialize(Codec.LONG).copyOnDeath().build());

    private Coins() {}

    public static long get(Player player) {
        return player.getData(COPPER);
    }

    public static void set(ServerPlayer player, long copper) {
        player.setData(COPPER, Math.max(0L, copper));
        sync(player);
    }

    public static void add(ServerPlayer player, long copper) {
        set(player, get(player) + copper);
    }

    public static void sync(ServerPlayer player) {
        PacketDistributor.sendToPlayer(player, new CoinsPayload(get(player)));
    }

    public static long gold(long copper) { return copper / 10000L; }
    public static long silver(long copper) { return (copper / 100L) % 100L; }
    public static long copperPart(long copper) { return copper % 100L; }
}
