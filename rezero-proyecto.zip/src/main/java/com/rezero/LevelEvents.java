package com.rezero;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.entity.player.PlayerXpEvent;

/** Quita la experiencia de Minecraft (orbes, XP, niveles) y la mesa de encantamientos. */
public final class LevelEvents {
    private LevelEvents() {}

    public static void register() {
        var bus = NeoForge.EVENT_BUS;
        bus.addListener(LevelEvents::onJoin);
        bus.addListener(LevelEvents::onXpChange);
        bus.addListener(LevelEvents::onLevelChange);
        bus.addListener(LevelEvents::onRightClickBlock);
    }

    /** Ninguna orbe de XP llega a existir (mobs, minerales, hornos, crianza, pesca...). */
    private static void onJoin(EntityJoinLevelEvent event) {
        if (event.getEntity() instanceof ExperienceOrb) event.setCanceled(true);
        // Sin slimes vanilla (los de colores de ModSlimes los sustituyen): ni naturales, ni huevo, ni guardados en el mundo.
        if (event.getEntity().getType() == net.minecraft.world.entity.EntityType.SLIME) event.setCanceled(true);
    }

    private static void onXpChange(PlayerXpEvent.XpChange event) {
        event.setCanceled(true);
    }

    private static void onLevelChange(PlayerXpEvent.LevelChange event) {
        event.setCanceled(true);
    }

    private static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!event.getLevel().getBlockState(event.getPos()).is(Blocks.ENCHANTING_TABLE)) return;
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.FAIL);
        if (!event.getLevel().isClientSide) {
            event.getEntity().displayClientMessage(Component.literal("La mesa de encantamientos está desactivada."), true);
        }
    }
}
