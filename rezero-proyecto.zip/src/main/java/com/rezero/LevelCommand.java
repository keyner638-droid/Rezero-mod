package com.rezero;

import com.mojang.brigadier.Command;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/** /reiniciarxp: pone tu XP (y por tanto tu nivel) en 0. No toca los puntos ganados. Solo OP. */
public final class LevelCommand {
    private LevelCommand() {}

    public static void register() {
        NeoForge.EVENT_BUS.addListener(LevelCommand::onRegister);
    }

    private static void onRegister(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("reiniciarxp")
                .requires(s -> s.hasPermission(2))
                .executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    p.setData(Coins.XP, 0L);
                    Coins.sync(p);
                    ctx.getSource().sendSuccess(() -> Component.literal("XP reiniciada: nivel 0."), false);
                    return Command.SINGLE_SUCCESS;
                }));
    }
}
