package com.rezero;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Slimes de colores: slimes normales (misma IA y animaciones) pero siempre medianos y sin division, ver {@link ColoredSlime}.
 * Aparecen en la superficie, de dia, en los biomas de data/rezero/neoforge/biome_modifier/colored_slime_spawns.json.
 */
public final class ModSlimes {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, ReZero.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<ColoredSlime>> RED = slime("red_slime");
    public static final DeferredHolder<EntityType<?>, EntityType<ColoredSlime>> BLUE = slime("blue_slime");
    public static final DeferredHolder<EntityType<?>, EntityType<ColoredSlime>> YELLOW = slime("yellow_slime");
    public static final DeferredHolder<EntityType<?>, EntityType<ColoredSlime>> PINK = slime("pink_slime");

    private ModSlimes() {}

    /** Mismo tipo de entidad que el slime vanilla, con otro id. */
    private static DeferredHolder<EntityType<?>, EntityType<ColoredSlime>> slime(String id) {
        return ENTITIES.register(id, () -> EntityType.Builder.<ColoredSlime>of(ColoredSlime::new, MobCategory.MONSTER)
                .sized(0.52F, 0.52F)
                .eyeHeight(0.325F)
                .spawnDimensionsScale(4.0F)
                .clientTrackingRange(10)
                .build(id));
    }

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(RED.get(), Monster.createMonsterAttributes().build());
        event.put(BLUE.get(), Monster.createMonsterAttributes().build());
        event.put(YELLOW.get(), Monster.createMonsterAttributes().build());
        event.put(PINK.get(), Monster.createMonsterAttributes().build());
    }

    public static void registerSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        for (var holder : java.util.List.of(RED, BLUE, YELLOW, PINK)) {
            event.register(holder.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    ModSlimes::checkSpawn, RegisterSpawnPlacementsEvent.Operation.OR);
        }
    }

    /** Superficie y de dia (el slime vanilla es de pantano/cueva): cielo abierto, dia, no en pacifico. */
    private static boolean checkSpawn(EntityType<ColoredSlime> type, ServerLevelAccessor level, MobSpawnType spawnType,
                                      BlockPos pos, RandomSource random) {
        return level.getDifficulty() != Difficulty.PEACEFUL
                && level.getLevel().isDay()
                && level.canSeeSky(pos)
                && Mob.checkMobSpawnRules(type, level, spawnType, pos, random);
    }
}
