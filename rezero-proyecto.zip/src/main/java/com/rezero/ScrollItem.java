package com.rezero;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/**
 * Pergamino: lo suelta el Zombie Mago Errante. Por ahora no hace nada.
 * TODO: darle funcion (sobrescribir {@code use(...)} aqui cuando se decida).
 */
public class ScrollItem extends Item {
    public ScrollItem(Properties properties) {
        super(properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.rezero.scroll.desc").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
    }
}
