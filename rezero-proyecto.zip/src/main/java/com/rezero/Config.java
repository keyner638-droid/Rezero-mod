package com.rezero;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class Config {
    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    public static final ModConfigSpec.BooleanValue ENABLED = B
            .comment("Activa el Retorno por la Muerte.")
            .define("enabled", true);

    public static final ModConfigSpec.IntValue CHECKPOINT_SECONDS = B
            .comment("Cada cuantos segundos se guarda un punto de retorno.")
            .defineInRange("checkpointSeconds", 15, 1, 600);

    public static final ModConfigSpec.IntValue PAUSE_AFTER_RETURN_SECONDS = B
            .comment("Segundos sin guardar un punto nuevo despues de retornar.")
            .defineInRange("pauseAfterReturnSeconds", 60, 0, 3600);

    public static final ModConfigSpec.IntValue RADIUS = B
            .comment("Radio (en bloques) alrededor del jugador que vuelve al pasado: bloques, cofres, mobs e items.")
            .defineInRange("radiusBlocks", 64, 16, 256);

    public static final ModConfigSpec.IntValue MAX_BLOCK_CHANGES = B
            .comment("Maximo de bloques cambiados que se recuerdan por punto. Si se supera, se guarda un punto nuevo.")
            .defineInRange("maxBlockChanges", 300000, 1000, 5000000);

    public static final ModConfigSpec.DoubleValue INVULNERABLE_SECONDS = B
            .comment("Segundos de invulnerabilidad despues de retornar (0 = sin invulnerabilidad).")
            .defineInRange("invulnerableSeconds", 3.6, 0.0, 60.0);

    public static final ModConfigSpec.IntValue SEASON4_CHANCE = B
            .comment("Probabilidad (%) de que al retornar suene el sonido de la temporada 4 en vez del normal.")
            .defineInRange("season4ChancePercent", 30, 0, 100);

    public static final ModConfigSpec.IntValue LOVE_CHANCE = B
            .comment("Probabilidad (%) de que suene el 'I love you' (pantalla totalmente negra mientras dura). Se tira antes que el de la temporada 4.")
            .defineInRange("loveChancePercent", 5, 0, 100);

    public static final ModConfigSpec.DoubleValue XP_PER_HEALTH = B
            .comment("XP que da un enemigo agresivo por cada punto de vida maxima (se suma directo al jugador).")
            .defineInRange("xpPerHealth", 1.0, 0.0, 1000.0);

    public static final ModConfigSpec.IntValue MAX_MANA = B
            .comment("Mana maxima del jugador.")
            .defineInRange("maxMana", 100, 1, 100000);

    public static final ModConfigSpec.IntValue MANA_REGEN = B
            .comment("Mana que se recupera por segundo.")
            .defineInRange("manaRegenPerSecond", 5, 0, 100000);

    public static final ModConfigSpec.DoubleValue WAND_DAMAGE = B
            .comment("Dano de la chispa de la varita en puntos de vida (2 = un corazon; 3 = corazon y medio).")
            .defineInRange("wandDamagePoints", 3.0, 0.0, 100.0);

    public static final ModConfigSpec.IntValue WAND_MANA_COST = B
            .comment("Mana que gasta cada chispa de la varita.")
            .defineInRange("wandManaCost", 10, 0, 1000);

    public static final ModConfigSpec.IntValue WAND_COOLDOWN_TICKS = B
            .comment("Cooldown de la varita en ticks (20 = 1 segundo).")
            .defineInRange("wandCooldownTicks", 10, 0, 1200);

    public static final ModConfigSpec.DoubleValue WAND_RANGE = B
            .comment("Alcance de la chispa de la varita, en bloques.")
            .defineInRange("wandRangeBlocks", 7.0, 1.0, 64.0);

    public static final ModConfigSpec.DoubleValue WAND_DROP = B
            .comment("Cuanto cae la chispa (gravedad) al llegar al maximo alcance, en bloques. 0 = vuela recta.")
            .defineInRange("wandDropAtMaxRange", 1.0, 0.0, 20.0);

    public static final ModConfigSpec.IntValue YELLOW_FIRE_SECONDS = B
            .comment("Segundos que dura el fuego amarillo del Zombie Mago Errante.")
            .defineInRange("yellowFireSeconds", 5, 1, 600);

    public static final ModConfigSpec.DoubleValue YELLOW_FIRE_MANA_REGEN = B
            .comment("Multiplicador de la recarga de mana mientras se arde con fuego amarillo (0.5 = a la mitad).")
            .defineInRange("yellowFireManaRegenMultiplier", 0.5, 0.0, 1.0);

    public static final ModConfigSpec.IntValue MANA_IDLE_SECONDS = B
            .comment("Segundos sin usar armas de mana para que empiece la recarga rapida.")
            .defineInRange("manaIdleSeconds", 3, 0, 600);

    public static final ModConfigSpec.DoubleValue MANA_IDLE_MULTIPLIER = B
            .comment("Multiplicador de la recarga de mana cuando no se usan armas de mana.")
            .defineInRange("manaIdleMultiplier", 2.5, 1.0, 100.0);

    public static final ModConfigSpec.IntValue HAT_MANA_BONUS = B
            .comment("Mana maxima extra que da el Sombrero del Mago Errante mientras lo llevas puesto.")
            .defineInRange("hatManaBonus", 50, 0, 100000);

    public static final ModConfigSpec.IntValue HAT_COST_REDUCTION = B
            .comment("Porcentaje (%) que reduce el coste de mana de las armas el Sombrero del Mago Errante.")
            .defineInRange("hatManaCostReductionPercent", 5, 0, 100);

    public static final ModConfigSpec SPEC = B.build();

    private Config() {}
}
