package com.rezero;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class Config {
    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    public static final ModConfigSpec.BooleanValue ENABLED = B
            .comment("Activa el Retorno por la Muerte.")
            .define("enabled", true);

    public static final ModConfigSpec.IntValue CHECKPOINT_SECONDS = B
            .comment("Cada cuantos segundos se guarda un punto de retorno.")
            .defineInRange("checkpointSeconds", 15, 1, 600);

    public static final ModConfigSpec.IntValue PAUSE_AFTER_RETURN_SECONDS = B
            .comment("Segundos sin guardar un punto nuevo despues de retornar.")
            .defineInRange("pauseAfterReturnSeconds", 60, 0, 3600);

    public static final ModConfigSpec.IntValue RADIUS = B
            .comment("Radio (en bloques) alrededor del jugador que vuelve al pasado: bloques, cofres, mobs e items.")
            .defineInRange("radiusBlocks", 64, 16, 256);

    public static final ModConfigSpec.IntValue MAX_BLOCK_CHANGES = B
            .comment("Maximo de bloques cambiados que se recuerdan por punto. Si se supera, se guarda un punto nuevo.")
            .defineInRange("maxBlockChanges", 300000, 1000, 5000000);

    public static final ModConfigSpec SPEC = B.build();

    private Config() {}
}
