package com.rezero.client;

import com.rezero.rune.Quality;
import com.rezero.rune.RuneDef;
import com.rezero.rune.RuneForge;
import com.rezero.rune.RuneForgeMenu;
import com.rezero.rune.RuneInstance;
import com.rezero.rune.RuneRegistry;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

/** Pantalla de la Forja Runica: objeto + runa -> resultado, con info de la runa y barra de capacidad. Dibujada por codigo (sin texturas). */
public class RuneForgeScreen extends AbstractContainerScreen<RuneForgeMenu> {
    private static final int PANEL_X = 8, PANEL_Y = 47, PANEL_W = 160, PANEL_H = 74;
    private static final int C_BORDER = 0xFF4A3D70, C_SLOT = 0xFF0E0A1C, C_TEXT = 0xFFE8DDFF, C_DIM = 0xFF9A90B0;
    private static final int C_USED = 0xFFE0A030, C_FREE = 0xFF2E2648, C_NEW = 0xFF55FF77, C_BAD = 0xFFFF5555;

    private Button confirm;
    private RuneForge.Preview preview;

    public RuneForgeScreen(RuneForgeMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = 216;
        this.titleLabelX = 8;
        this.titleLabelY = 6;
        this.inventoryLabelX = 8;
        this.inventoryLabelY = 124;
    }

    @Override
    protected void init() {
        super.init();
        confirm = addRenderableWidget(Button.builder(Component.translatable("rune.rezero.forge.confirm"),
                        b -> {
                            if (minecraft != null && minecraft.gameMode != null) {
                                minecraft.gameMode.handleInventoryButtonClick(menu.containerId, RuneForgeMenu.BUTTON_CONFIRM);
                            }
                        })
                .bounds(leftPos + 114, topPos + 17, 54, 20).build());
        refresh();
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        refresh();
    }

    private void refresh() {
        preview = RuneForge.preview(menu.targetStack(), menu.runeStack());
        if (confirm != null) confirm.active = preview.ok();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(font, title, titleLabelX, titleLabelY, C_TEXT, false);
        g.drawString(font, playerInventoryTitle, inventoryLabelX, inventoryLabelY, C_DIM, false);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        if (preview == null) refresh();
        int x = leftPos, y = topPos;

        // marco y fondo
        g.fill(x - 1, y - 1, x + imageWidth + 1, y + imageHeight + 1, 0xFF0B0814);
        g.fillGradient(x, y, x + imageWidth, y + imageHeight, 0xFF2A2140, 0xFF17112A);
        g.renderOutline(x + 1, y + 1, imageWidth - 2, imageHeight - 2, C_BORDER);

        // casillas
        for (Slot s : menu.slots) {
            int sx = x + s.x - 1, sy = y + s.y - 1;
            g.fill(sx, sy, sx + 18, sy + 18, C_SLOT);
            g.renderOutline(sx, sy, 18, 18, 0xFF3A2F5C);
        }
        // runa colocada: casilla resaltada con el color de su calidad
        if (preview.rune() != null) {
            g.renderOutline(x + 47, y + 17, 18, 18, 0xFF000000 | preview.rune().qualityEnum().color());
        }
        // resultado: pulsa en dorado si se puede forjar
        if (preview.ok()) {
            double pulse = 0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 220.0);
            int a = 120 + (int) (135 * pulse);
            g.renderOutline(x + 85, y + 17, 18, 18, (a << 24) | 0xFFD060);
        }

        // simbolos y rotulos de la fila superior
        g.drawCenteredString(font, "+", x + 38, y + 23, C_DIM);
        g.drawCenteredString(font, "→", x + 76, y + 23, preview.ok() ? 0xFFFFD060 : C_DIM);
        g.drawCenteredString(font, Component.translatable("rune.rezero.forge.slot_item"), x + 19, y + 38, C_DIM);
        g.drawCenteredString(font, Component.translatable("rune.rezero.forge.slot_rune"), x + 57, y + 38, C_DIM);
        g.drawCenteredString(font, Component.translatable("rune.rezero.forge.slot_result"), x + 95, y + 38, C_DIM);

        // panel de informacion
        int px = x + PANEL_X, py = y + PANEL_Y;
        g.fill(px, py, px + PANEL_W, py + PANEL_H, 0xFF120D22);
        g.renderOutline(px, py, PANEL_W, PANEL_H, C_BORDER);
        drawInfo(g, px + 6, py + 5, PANEL_W - 12);
    }

    private void drawInfo(GuiGraphics g, int x, int y, int w) {
        RuneForge.Preview p = preview;
        RuneInstance shown = p.after() != null ? p.after() : p.rune();
        RuneDef def = shown == null ? null : RuneRegistry.get(shown.id());

        if (def != null) {
            // linea 1: nombre y calidad (con la mejora si la hay)
            Quality qa = shown.qualityEnum();
            var line = Component.literal("◆ ").append(def.name()).append(" (");
            if (p.before() != null && p.before().quality() != shown.quality()) {
                line.append(p.before().qualityEnum().displayName()).append(" → ");
            }
            line.append(qa.displayName()).append(")");
            g.drawString(font, line, x, y, 0xFF000000 | qa.color(), false);
            // linea 2: efecto
            g.drawString(font, def.description(qa), x, y + 10, 0xFF8FE08F, false);
            // linea 3: costo
            g.drawString(font, Component.translatable("rune.rezero.forge.cost", def.cost()), x, y + 20, 0xFFE8C46A, false);
        } else {
            g.drawString(font, Component.translatable("rune.rezero.forge.no_rune"), x, y, C_DIM, false);
        }

        // capacidad: solo si hay un objeto con capacidad
        if (p.max() > 0) {
            int shownUsed = p.ok() ? p.usedAfter() : p.used();
            g.drawString(font, Component.translatable("rune.rezero.forge.capacity", shownUsed, p.max()), x, y + 30, C_TEXT, false);
            Component rest = Component.translatable("rune.rezero.forge.remaining", Math.max(0, p.max() - shownUsed));
            g.drawString(font, rest, x + w - font.width(rest), y + 30, C_DIM, false);
            drawBar(g, x, y + 41, w, p);
        }

        // mensaje de estado (hasta 2 lineas)
        int color = p.ok() ? 0xFF8FE08F : (p.status() == RuneForge.Status.EMPTY || p.status() == RuneForge.Status.NEED_RUNE
                || p.status() == RuneForge.Status.NEED_ITEM ? C_DIM : 0xFFFF7777);
        int ly = y + 51;
        for (FormattedCharSequence seq : font.split(FormattedText.of(Component.translatable(p.status().langKey()).getString()), w)) {
            if (ly > y + 62) break;
            g.drawString(font, seq, x, ly, color, false);
            ly += 9;
        }
    }

    /** Barra segmentada: oro = usado, verde = lo que añade esta runa, rojo = no cabe, oscuro = libre. */
    private void drawBar(GuiGraphics g, int x, int y, int w, RuneForge.Preview p) {
        int max = p.max();
        int gap = max > 24 ? 0 : 1;
        float seg = (w - gap * (max - 1)) / (float) max;
        RuneDef def = p.rune() == null ? null : RuneRegistry.get(p.rune().id());
        int cost = def == null ? 0 : def.cost();
        for (int i = 0; i < max; i++) {
            int color = C_FREE;
            if (i < p.used()) color = C_USED;
            else if (p.status() == RuneForge.Status.OK_INSERT && i < p.used() + cost) color = C_NEW;
            else if (p.status() == RuneForge.Status.NO_CAPACITY && i < p.used() + cost) color = C_BAD;
            int x0 = x + Math.round(i * (seg + gap));
            int x1 = x + Math.round(i * (seg + gap) + seg);
            g.fill(x0, y, Math.max(x0 + 1, x1), y + 6, 0xFF000000 | color);
        }
    }
}
