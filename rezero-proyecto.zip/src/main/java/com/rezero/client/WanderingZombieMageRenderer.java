package com.rezero.client;

import com.rezero.ReZero;
import com.rezero.WanderingZombieMage;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

public class WanderingZombieMageRenderer extends HumanoidMobRenderer<WanderingZombieMage, WanderingZombieMageModel> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "textures/entity/wandering_zombie_mage.png");
    private static final ResourceLocation GLOW =
            ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "textures/entity/wandering_zombie_mage_glow.png");

    public WanderingZombieMageRenderer(EntityRendererProvider.Context context) {
        super(context, new WanderingZombieMageModel(context.bakeLayer(WanderingZombieMageModel.LAYER)), 0.5F);
        this.addLayer(new GlowLayer(this));
    }

    @Override
    public ResourceLocation getTextureLocation(WanderingZombieMage entity) {
        return TEXTURE;
    }

    /** Ojos y cristal de la linterna brillan en la oscuridad. */
    private static final class GlowLayer extends EyesLayer<WanderingZombieMage, WanderingZombieMageModel> {
        GlowLayer(RenderLayerParent<WanderingZombieMage, WanderingZombieMageModel> parent) {
            super(parent);
        }

        @Override
        public RenderType renderType() {
            return RenderType.eyes(GLOW);
        }
    }
}
