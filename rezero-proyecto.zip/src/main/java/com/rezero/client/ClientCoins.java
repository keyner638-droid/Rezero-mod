package com.rezero.client;

import com.rezero.Coins;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.neoforged.neoforge.client.event.ScreenEvent;

/** Total de monedas en el cliente y su "estadistica" a la derecha del inventario. */
public final class ClientCoins {
    public static long copper = 0L;

    private ClientCoins() {}

    public static void reset() {
        copper = 0L;
    }

    public static void onScreenRender(ScreenEvent.Render.Post event) {
        if (!(event.getScreen() instanceof InventoryScreen screen)) return;
        GuiGraphics g = event.getGuiGraphics();
        Font font = Minecraft.getInstance().font;

        String[] names = {"Oro", "Plata", "Cobre"};
        long[] values = {Coins.gold(copper), Coins.silver(copper), Coins.copperPart(copper)};
        int[] colors = {0xFFFFD700, 0xFFC8C8D2, 0xFFD2884B};

        int width = font.width("Monedas");
        String[] lines = new String[3];
        for (int i = 0; i < 3; i++) {
            lines[i] = names[i] + ": " + values[i];
            width = Math.max(width, font.width(lines[i]) + 10);
        }

        int x = screen.getGuiLeft() + screen.getXSize() + 6;
        int y = screen.getGuiTop() + 6;
        int h = 12 + 3 * 11 + 4;
        g.fill(x - 4, y - 4, x + width + 4, y - 4 + h + 4, 0xE0101010);
        g.renderOutline(x - 4, y - 4, width + 8, h + 4, 0xFF555555);
        g.drawString(font, "Monedas", x, y, 0xFFFFFFFF, false);
        for (int i = 0; i < 3; i++) {
            int ly = y + 12 + i * 11;
            g.fill(x, ly + 1, x + 6, ly + 7, colors[i]);
            g.drawString(font, lines[i], x + 10, ly, colors[i], false);
        }
    }
}
