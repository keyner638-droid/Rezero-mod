package com.rezero.client;

import com.rezero.Coins;
import com.rezero.ReZero;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.client.event.ScreenEvent;

/** Total de monedas en el cliente y su "estadistica" a la derecha del inventario. */
public final class ClientCoins {
    public static long copper = 0L;
    public static long xp = 0L;
    public static int mana = 0;
    public static int maxMana = 100;

    private ClientCoins() {}

    public static void reset() {
        copper = 0L;
        xp = 0L;
        mana = 0;
    }

    private static final ResourceLocation[] ICONS = {
            ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "textures/gui/coin_gold.png"),
            ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "textures/gui/coin_silver.png"),
            ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "textures/gui/coin_copper.png")};
    private static final int ICON_SIZE = 10;
    private static final int TEX_SIZE = 32;

    public static void onScreenRender(ScreenEvent.Render.Post event) {
        if (!(event.getScreen() instanceof InventoryScreen screen)) return;
        GuiGraphics g = event.getGuiGraphics();
        Font font = Minecraft.getInstance().font;

        long[] values = {Coins.gold(copper), Coins.silver(copper), Coins.copperPart(copper)};
        int[] colors = {0xFFFFD700, 0xFFC8C8D2, 0xFFD2884B};

        int width = font.width("Monedas");
        String[] lines = new String[3];
        for (int i = 0; i < 3; i++) {
            lines[i] = String.valueOf(values[i]);
            width = Math.max(width, ICON_SIZE + 4 + font.width(lines[i]));
        }

        int h = 12 + 3 * 12;
        // A la izquierda del inventario (si el libro de recetas esta abierto, a la izquierda del libro).
        int shift = screen.getRecipeBookComponent().isVisible() ? 150 : 0;
        int x = screen.getGuiLeft() - shift - width - 10;
        int y = screen.getGuiTop() + 6;
        g.fill(x - 4, y - 4, x + width + 4, y + h, 0xE0101010);
        g.renderOutline(x - 4, y - 4, width + 8, h + 4, 0xFF555555);
        g.drawString(font, "Monedas", x, y, 0xFFFFFFFF, false);
        for (int i = 0; i < 3; i++) {
            int ly = y + 12 + i * 12;
            g.blit(ICONS[i], x, ly, ICON_SIZE, ICON_SIZE, 0f, 0f, TEX_SIZE, TEX_SIZE, TEX_SIZE, TEX_SIZE);
            g.drawString(font, lines[i], x + ICON_SIZE + 4, ly + 1, colors[i], false);
        }
    }
}
