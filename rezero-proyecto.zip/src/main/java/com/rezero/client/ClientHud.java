package com.rezero.client;

import com.rezero.Levels;
import com.rezero.ReZero;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;

/** Interfaz propia arriba a la izquierda: retrato, nivel, XP, vida y hambre. Solo en juego (no con inventarios abiertos). */
public final class ClientHud {
    public static final ResourceLocation LAYER_ID = ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "hud");
    private static final ResourceLocation PORTRAIT =
            ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "textures/gui/portrait.png");
    private static final int PORTRAIT_W = 37, PORTRAIT_H = 40;

    private static final int PANEL = 0xD0101018;
    private static final int TRACK = 0xFF23242C;
    private static final int BORDER = 0xFF4A4F63;

    private ClientHud() {}

    public static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.options.hideGui || p.isSpectator()) return;
        if (mc.screen != null && !(mc.screen instanceof ChatScreen)) return;
        Font font = mc.font;

        int x = 6, y = 6, box = 40;

        // Retrato con el nivel debajo
        g.fill(x, y, x + box, y + box, PANEL);
        g.blit(PORTRAIT, x + 2, y + 1, box - 4, box - 4, 0f, 0f, PORTRAIT_W, PORTRAIT_H, PORTRAIT_W, PORTRAIT_H);
        int level = Levels.levelOf(ClientCoins.xp);
        String lv = "Nv " + level;
        g.fill(x, y + box - 11, x + box, y + box, 0xE0101018);
        g.drawCenteredString(font, lv, x + box / 2, y + box - 9, 0xFFFFFFFF);
        g.renderOutline(x, y, box, box, level >= 25 ? 0xFFFFD700 : level >= 10 ? 0xFFC8C8D2 : BORDER);
        if (ClientCoins.points > 0) {
            g.drawString(font, "Puntos: " + ClientCoins.points, x, y + box + 3, 0xFFFFD700, true);
        }

        // Barras
        int bx = x + box + 4, bw = 118, bh = 11, gap = 3;
        long into = ClientCoins.xp - Levels.totalForLevel(level);
        int need = Levels.needed(level);
        bar(g, font, bx, y, bw, bh, into / (float) need, 0xFF3B82F6, "XP " + into + " / " + need);

        int hp = (int) Math.ceil(p.getHealth()), maxHp = (int) Math.ceil(p.getMaxHealth());
        bar(g, font, bx, y + (bh + gap), bw, bh, maxHp <= 0 ? 0f : p.getHealth() / p.getMaxHealth(), 0xFFD93A3A,
                "Vida " + hp + " / " + maxHp);

        int maxMana = Math.max(1, ClientCoins.maxMana);
        int mana = Math.min(ClientCoins.mana, maxMana);
        bar(g, font, bx, y + 2 * (bh + gap), bw, bh, mana / (float) maxMana, 0xFF7C5CE0, "Mana " + mana + " / " + maxMana);

        // Circulos a la derecha: armadura arriba, hambre debajo (se rellenan de abajo hacia arriba)
        int r = 9, cx = bx + bw + 6 + r + 1;
        int armor = p.getArmorValue();
        int food = p.getFoodData().getFoodLevel();
        orb(g, font, cx, y + r + 1, r, armor / 20f, 0xFF9AA7B8, String.valueOf(armor));
        orb(g, font, cx, y + 3 * r + 3, r, food / 20f, 0xFFE0891E, String.valueOf(food));
    }

    /** Circulo que se rellena de abajo hacia arriba, con el valor en el centro. */
    private static void orb(GuiGraphics g, Font font, int cx, int cy, int r, float frac, int color, String text) {
        frac = Math.max(0f, Math.min(1f, frac));
        disc(g, cx, cy, r + 1, BORDER, 0, 1f);
        disc(g, cx, cy, r, TRACK, 0, 1f);
        if (frac > 0f) disc(g, cx, cy, r, color, 0, frac);
        g.drawCenteredString(font, text, cx, cy - 3, 0xFFFFFFFF);
    }

    /** Dibuja un disco por filas; solo se pintan las filas del tercio inferior {@code frac} (de abajo hacia arriba). */
    private static void disc(GuiGraphics g, int cx, int cy, int r, int color, int unused, float frac) {
        int rows = 2 * r;
        int firstRow = Math.round(rows * (1f - frac));
        for (int row = firstRow; row < rows; row++) {
            double dy = row + 0.5 - r;
            int hw = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
            if (hw <= 0) continue;
            g.fill(cx - hw, cy - r + row, cx + hw, cy - r + row + 1, color);
        }
    }

    private static void bar(GuiGraphics g, Font font, int x, int y, int w, int h, float frac, int color, String text) {
        frac = Math.max(0f, Math.min(1f, frac));
        g.fill(x, y, x + w, y + h, PANEL);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, TRACK);
        int fw = Math.round((w - 2) * frac);
        if (fw > 0) g.fill(x + 1, y + 1, x + 1 + fw, y + h - 1, color);
        g.renderOutline(x, y, w, h, BORDER);
        g.drawCenteredString(font, text, x + w / 2, y + (h - 8) / 2 + 1, 0xFFFFFFFF);
    }
}
