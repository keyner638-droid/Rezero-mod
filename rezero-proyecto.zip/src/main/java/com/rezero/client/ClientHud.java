package com.rezero.client;

import com.rezero.Levels;
import com.rezero.ReZero;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;

/** Interfaz propia arriba a la izquierda: retrato, nivel, XP, vida y hambre. Solo en juego (no con inventarios abiertos). */
public final class ClientHud {
    public static final ResourceLocation LAYER_ID = ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "hud");
    private static final ResourceLocation PORTRAIT =
            ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "textures/gui/portrait.png");
    private static final int PORTRAIT_W = 37, PORTRAIT_H = 40;

    private static final int PANEL = 0xD0101018;
    private static final int TRACK = 0xFF23242C;
    private static final int BORDER = 0xFF4A4F63;

    private ClientHud() {}

    public static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.options.hideGui || p.isSpectator()) return;
        if (mc.screen != null && !(mc.screen instanceof ChatScreen)) return;
        Font font = mc.font;

        int x = 6, y = 6, box = 40;

        // Retrato con el nivel debajo
        g.fill(x, y, x + box, y + box, PANEL);
        g.blit(PORTRAIT, x + 2, y + 1, box - 4, box - 4, 0f, 0f, PORTRAIT_W, PORTRAIT_H, PORTRAIT_W, PORTRAIT_H);
        int level = Levels.levelOf(ClientCoins.xp);
        String lv = "Nv " + level;
        g.fill(x, y + box - 11, x + box, y + box, 0xE0101018);
        g.drawCenteredString(font, lv, x + box / 2, y + box - 9, 0xFFFFFFFF);
        g.renderOutline(x, y, box, box, BORDER);

        // Barras
        int bx = x + box + 4, bw = 118, bh = 11, gap = 3;
        long into = ClientCoins.xp - Levels.totalForLevel(level);
        int need = Levels.needed(level);
        bar(g, font, bx, y, bw, bh, into / (float) need, 0xFF3B82F6, "XP " + into + " / " + need);

        int hp = (int) Math.ceil(p.getHealth()), maxHp = (int) Math.ceil(p.getMaxHealth());
        bar(g, font, bx, y + (bh + gap), bw, bh, maxHp <= 0 ? 0f : p.getHealth() / p.getMaxHealth(), 0xFFD93A3A,
                "Vida " + hp + " / " + maxHp);

        int food = p.getFoodData().getFoodLevel();
        bar(g, font, bx, y + 2 * (bh + gap), bw, bh, food / 20f, 0xFFE0891E, "Hambre " + food + " / 20");
    }

    private static void bar(GuiGraphics g, Font font, int x, int y, int w, int h, float frac, int color, String text) {
        frac = Math.max(0f, Math.min(1f, frac));
        g.fill(x, y, x + w, y + h, PANEL);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, TRACK);
        int fw = Math.round((w - 2) * frac);
        if (fw > 0) g.fill(x + 1, y + 1, x + 1 + fw, y + h - 1, color);
        g.renderOutline(x, y, w, h, BORDER);
        g.drawCenteredString(font, text, x + w / 2, y + (h - 8) / 2 + 1, 0xFFFFFFFF);
    }
}
