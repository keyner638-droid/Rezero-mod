package com.rezero.client;

import com.rezero.rune.RuneDef;
import com.rezero.rune.RuneInstance;
import com.rezero.rune.RuneItem;
import com.rezero.rune.RuneLogic;
import com.rezero.rune.RuneRegistry;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

/** Tooltip automatico: Capacidad Rúnica y lista de runas del objeto. */
public final class RuneTooltips {
    private RuneTooltips() {}

    public static void onTooltip(ItemTooltipEvent event) {
        ItemStack stack = event.getItemStack();
        if (stack.getItem() instanceof RuneItem) return;
        int max = RuneLogic.maxCapacity(stack);
        List<RuneInstance> runes = RuneLogic.runesOf(stack);
        if (max <= 0 && runes.isEmpty()) return;
        List<Component> tip = event.getToolTip();
        tip.add(Component.empty());
        tip.add(Component.translatable("rune.rezero.capacity", RuneLogic.usedCapacity(stack), max)
                .withStyle(ChatFormatting.GOLD));
        if (runes.isEmpty()) return;
        tip.add(Component.translatable("rune.rezero.runes_header").withStyle(ChatFormatting.GRAY));
        for (RuneInstance r : runes) {
            RuneDef def = RuneRegistry.get(r.id());
            if (def == null) continue;
            var q = r.qualityEnum();
            tip.add(Component.literal("◆ ").append(def.name()).append(" (").append(q.displayName()).append(")")
                    .withStyle(Style.EMPTY.withColor(q.color())));
            tip.add(def.description(q).copy().withStyle(ChatFormatting.GRAY));
        }
    }
}
