package com.rezero.client;

import com.rezero.ModItems;
import com.rezero.ReZero;
import com.rezero.rune.RuneComponents;
import com.rezero.rune.RuneInstance;
import com.rezero.rune.RuneRegistry;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;

/**
 * Cada runa tiene su propia textura (estilo plantilla de herreria) y un marco que se tiñe segun la calidad.
 * El tipo se elige con la propiedad "rezero:rune_type" = (posicion en runes.json + 1) / 16 (maximo 16 runas con textura).
 */
public final class RuneClient {
    private RuneClient() {}

    public static void registerItemColors(RegisterColorHandlersEvent.Item event) {
        event.register((stack, tintIndex) -> {
            if (tintIndex != 1) return -1; // capa 0 (dibujo de la runa) sin tinte
            RuneInstance r = stack.get(RuneComponents.RUNE.get());
            return r == null ? -1 : 0xFF000000 | r.qualityEnum().color(); // capa 1 (marco) = calidad
        }, ModItems.RUNE.get());
    }

    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            List<String> ids = new ArrayList<>(RuneRegistry.ids());
            ItemProperties.register(ModItems.RUNE.get(),
                    ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "rune_type"),
                    (stack, level, entity, seed) -> {
                        RuneInstance r = stack.get(RuneComponents.RUNE.get());
                        if (r == null) return 0.0F;
                        int i = ids.indexOf(r.id());
                        return i < 0 || i >= 16 ? 0.0F : (i + 1) / 16.0F;
                    });
        });
    }
}
