package com.rezero.client;

import com.rezero.ModItems;
import com.rezero.rune.RuneComponents;
import com.rezero.rune.RuneInstance;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;

/** Tiñe la textura de la runa segun su calidad. */
public final class RuneClient {
    private RuneClient() {}

    public static void registerItemColors(RegisterColorHandlersEvent.Item event) {
        event.register((stack, tintIndex) -> {
            if (tintIndex != 0) return -1;
            RuneInstance r = stack.get(RuneComponents.RUNE.get());
            return r == null ? -1 : 0xFF000000 | r.qualityEnum().color();
        }, ModItems.RUNE.get());
    }
}
