package com.rezero.client;

import com.rezero.ReZero;
import com.rezero.WanderingZombieMage;
import net.minecraft.client.model.AnimationUtils;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Zombie con tunica, capa, sombrero de mago y una linterna 3D colgando de la mano derecha.
 * Textura de 128x128 (la parte de arriba a la izquierda es el zombie normal; el resto es tunica, sombrero y linterna).
 * El sombrero ({@link #addHat}) lo reutiliza {@link WanderingMageHatModel} con la misma distribucion de UV.
 */
public class WanderingZombieMageModel extends HumanoidModel<WanderingZombieMage> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "wandering_zombie_mage"), "main");

    private final ModelPart lantern;

    public WanderingZombieMageModel(ModelPart root) {
        super(root);
        this.lantern = root.getChild("right_arm").getChild("lantern");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();

        // Sombrero (hijo de la cabeza, asi sigue sus giros)
        addHat(root.getChild("head"));

        // Tunica: parte de arriba sobre el torso, falda hasta casi los pies, cinturon de cuerda y capa por detras
        PartDefinition body = root.getChild("body");
        body.addOrReplaceChild("robe_top", CubeListBuilder.create().texOffs(16, 32)
                .addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, new CubeDeformation(0.5F)), PartPose.ZERO);
        body.addOrReplaceChild("robe_skirt", CubeListBuilder.create().texOffs(0, 48)
                .addBox(-5.0F, 12.0F, -3.0F, 10, 9, 6), PartPose.ZERO);
        body.addOrReplaceChild("robe_belt", CubeListBuilder.create().texOffs(88, 32)
                .addBox(-4.0F, 9.0F, -2.0F, 8, 1, 4, new CubeDeformation(0.7F)), PartPose.ZERO);
        body.addOrReplaceChild("cape", CubeListBuilder.create().texOffs(64, 32)
                .addBox(-4.5F, 0.0F, 0.0F, 9, 16, 1), PartPose.offsetAndRotation(0.0F, 1.0F, 2.7F, 0.12F, 0.0F, 0.0F));

        // Mangas
        root.getChild("right_arm").addOrReplaceChild("sleeve", CubeListBuilder.create().texOffs(40, 32)
                .addBox(-3.0F, -2.0F, -2.0F, 4, 6, 4, new CubeDeformation(0.5F)), PartPose.ZERO);
        root.getChild("left_arm").addOrReplaceChild("sleeve", CubeListBuilder.create().texOffs(40, 32).mirror()
                .addBox(-1.0F, -2.0F, -2.0F, 4, 6, 4, new CubeDeformation(0.5F)), PartPose.ZERO);

        // Linterna: el punto de giro esta en la punta de la mano (arm: y = 10) y cuelga hacia abajo
        root.getChild("right_arm").addOrReplaceChild("lantern", CubeListBuilder.create()
                        .texOffs(80, 112).addBox(-2.0F, 0.0F, -0.5F, 4, 3, 1)          // asa
                        .texOffs(0, 112).addBox(-3.0F, 3.0F, -3.0F, 6, 1, 6)           // tapa
                        .texOffs(56, 112).addBox(-2.5F, 4.0F, -2.5F, 5, 6, 5)          // cristal con la estrella
                        .texOffs(28, 112).addBox(-3.0F, 10.0F, -3.0F, 6, 1, 6),        // base
                PartPose.offset(-1.0F, 10.0F, 0.0F));

        return LayerDefinition.create(mesh, 128, 128);
    }

    /** Sombrero de mago: ala ancha, cono de dos pisos, punta doblada hacia atras, banda dorada con estrella. */
    public static void addHat(PartDefinition head) {
        head.addOrReplaceChild("hat_brim", CubeListBuilder.create().texOffs(0, 64)
                .addBox(-7.0F, -8.5F, -7.0F, 14, 1, 14), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.04F, 0.0F, 0.03F));
        head.addOrReplaceChild("hat_tier1", CubeListBuilder.create().texOffs(0, 80)
                .addBox(-4.5F, -12.0F, -4.5F, 9, 4, 9), PartPose.ZERO);
        head.addOrReplaceChild("hat_band", CubeListBuilder.create().texOffs(0, 96)
                .addBox(-4.5F, -10.0F, -4.5F, 9, 1, 9, new CubeDeformation(0.3F)), PartPose.ZERO);
        head.addOrReplaceChild("hat_star", CubeListBuilder.create().texOffs(40, 96)
                .addBox(-1.5F, -10.9F, -5.3F, 3, 3, 1), PartPose.ZERO);
        head.addOrReplaceChild("hat_tier2", CubeListBuilder.create().texOffs(40, 80)
                .addBox(-3.0F, -16.0F, -3.0F, 6, 4, 6), PartPose.ZERO);
        PartDefinition tip1 = head.addOrReplaceChild("hat_tip1", CubeListBuilder.create().texOffs(68, 80)
                .addBox(-1.5F, -3.0F, -1.5F, 3, 3, 3), PartPose.offsetAndRotation(0.0F, -16.0F, 0.0F, -0.35F, 0.0F, 0.25F));
        tip1.addOrReplaceChild("hat_tip2", CubeListBuilder.create().texOffs(84, 80)
                .addBox(-1.0F, -3.0F, -1.0F, 2, 3, 2), PartPose.offsetAndRotation(0.0F, -3.0F, 0.0F, -0.55F, 0.0F, 0.2F));
    }

    @Override
    public void setupAnim(WanderingZombieMage entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        // Brazos de zombie (el izquierdo ataca)...
        AnimationUtils.animateZombieArms(this.leftArm, this.rightArm, entity.isAggressive(), this.attackTime, ageInTicks);
        // ...pero el derecho sostiene la linterna delante, con un balanceo suave.
        this.rightArm.xRot = -1.0F + Mth.sin(ageInTicks * 0.08F) * 0.04F;
        // La linterna contrarresta la inclinacion del brazo para colgar siempre hacia abajo y se columpia un poco.
        this.lantern.xRot = -this.rightArm.xRot + Mth.sin(ageInTicks * 0.1F) * 0.08F
                + Mth.cos(limbSwing * 0.6662F) * 0.4F * limbSwingAmount;
        this.lantern.zRot = Mth.cos(ageInTicks * 0.07F) * 0.05F;
    }
}
