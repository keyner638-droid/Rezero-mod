package com.rezero.client;

import com.rezero.ModEntities;
import com.rezero.ModItems;
import com.rezero.ReZero;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.minecraft.client.player.Input;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundSource;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.client.event.sound.PlaySoundEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.common.NeoForge;

public final class ClientSetup {
    private ClientSetup() {}

    public static void init(IEventBus modBus) {
        modBus.addListener(ClientSetup::registerLayers);
        modBus.addListener(ClientSetup::registerRenderers);
        modBus.addListener(ClientSetup::registerModelLayers);
        modBus.addListener(ClientSetup::registerItemExtensions);
        modBus.addListener(RuneClient::registerItemColors);
        modBus.addListener(ClientSetup::registerScreens);
        NeoForge.EVENT_BUS.addListener(RuneTooltips::onTooltip);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onMovementInput);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onGuiLayerPre);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onInteraction);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onComputeFov);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onLogout);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onPlaySound);
        NeoForge.EVENT_BUS.addListener(ClientCoins::onScreenRender);
    }

    /** Capa de la animacion por encima de todo. */
    private static void registerLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(ReturnEffect.LAYER_ID, (graphics, deltaTracker) -> ReturnEffect.render(graphics));
        event.registerAboveAll(ClientHud.LAYER_ID, (graphics, deltaTracker) -> ClientHud.render(graphics));
        event.registerBelow(VanillaGuiLayers.HOTBAR, YellowFireOverlay.LAYER_ID, (graphics, deltaTracker) -> YellowFireOverlay.render(graphics));
    }

    private static void registerScreens(net.neoforged.neoforge.client.event.RegisterMenuScreensEvent event) {
        event.register(com.rezero.ModMenus.RUNE_FORGE.get(), RuneForgeScreen::new);
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.WANDERING_ZOMBIE_MAGE.get(), WanderingZombieMageRenderer::new);
    }

    private static void registerModelLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(WanderingZombieMageModel.LAYER, WanderingZombieMageModel::createBodyLayer);
        event.registerLayerDefinition(WanderingMageHatModel.LAYER, WanderingMageHatModel::createBodyLayer);
    }

    /** El sombrero se ve en 3D (no como un casco normal) cuando se lleva puesto. */
    private static void registerItemExtensions(RegisterClientExtensionsEvent event) {
        event.registerItem(new IClientItemExtensions() {
            private WanderingMageHatModel model;

            @Override
            public HumanoidModel<?> getHumanoidArmorModel(LivingEntity entity, ItemStack stack, EquipmentSlot slot, HumanoidModel<?> original) {
                if (model == null) {
                    model = new WanderingMageHatModel(Minecraft.getInstance().getEntityModels().bakeLayer(WanderingMageHatModel.LAYER));
                }
                return model;
            }
        }, ModItems.WANDERING_MAGE_HAT.get());
    }

    /** Sin controles de movimiento mientras dura el retorno. */
    private static void onMovementInput(MovementInputUpdateEvent event) {
        if (!ReturnEffect.active()) return;
        Input in = event.getInput();
        in.up = false;
        in.down = false;
        in.left = false;
        in.right = false;
        in.jumping = false;
        in.shiftKeyDown = false;
        in.forwardImpulse = 0f;
        in.leftImpulse = 0f;
    }

    /** Sin pegar, usar ni romper nada mientras dura el retorno. */
    private static void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        if (!ReturnEffect.active()) return;
        event.setCanceled(true);
        event.setSwingHand(false);
    }

    /** Sin interfaz (hotbar, corazones...) mientras dura el retorno. */
    private static void onGuiLayerPre(RenderGuiLayerEvent.Pre event) {
        if (ReturnEffect.active() && !event.getName().equals(ReturnEffect.LAYER_ID)) {
            event.setCanceled(true);
            return;
        }
        // Sin barra de XP de Minecraft ni vida/comida de abajo: van en la interfaz propia de arriba a la izquierda.
        var name = event.getName();
        if (name.equals(VanillaGuiLayers.EXPERIENCE_BAR) || name.equals(VanillaGuiLayers.EXPERIENCE_LEVEL)
                || name.equals(VanillaGuiLayers.PLAYER_HEALTH) || name.equals(VanillaGuiLayers.ARMOR_LEVEL) || name.equals(VanillaGuiLayers.FOOD_LEVEL)) {
            event.setCanceled(true);
        }
    }

    /** Efecto tunel / respiracion del campo de vision. */
    private static void onComputeFov(ViewportEvent.ComputeFov event) {
        float scale = ReturnEffect.fovScale();
        if (scale != 1f) event.setFOV(event.getFOV() * scale);
    }

    private static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ReturnEffect.reset();
        ClientCoins.reset();
    }

    /**
     * Sin musica de fondo de Minecraft (menu, juego, creativo, bajo el agua...). Los discos (categoria RECORDS) siguen
     * sonando, y la musica de este mod (namespace "rezero") tambien, para poder meter canciones nuevas mas adelante.
     */
    private static void onPlaySound(PlaySoundEvent event) {
        SoundInstance sound = event.getSound();
        if (sound == null) return;
        if (sound.getSource() == SoundSource.MUSIC && !ReZero.MODID.equals(sound.getLocation().getNamespace())) {
            event.setSound(null);
        }
    }
}
