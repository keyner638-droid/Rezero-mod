package com.rezero.client;

import net.minecraft.client.player.Input;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.common.NeoForge;

public final class ClientSetup {
    private ClientSetup() {}

    public static void init(IEventBus modBus) {
        modBus.addListener(ClientSetup::registerLayers);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onMovementInput);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onGuiLayerPre);
    }

    /** Capa negra por encima de todo. */
    private static void registerLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(ReturnEffect.LAYER_ID, (graphics, deltaTracker) -> {
            float a = ReturnEffect.alpha();
            if (a <= 0f) return;
            int alpha = Math.min(255, (int) (a * 255f));
            graphics.fill(0, 0, graphics.guiWidth(), graphics.guiHeight(), alpha << 24);
        });
    }

    /** Sin controles de movimiento mientras dura el retorno. */
    private static void onMovementInput(MovementInputUpdateEvent event) {
        if (!ReturnEffect.active()) return;
        Input in = event.getInput();
        in.up = false;
        in.down = false;
        in.left = false;
        in.right = false;
        in.jumping = false;
        in.shiftKeyDown = false;
        in.forwardImpulse = 0f;
        in.leftImpulse = 0f;
    }

    /** Sin interfaz (hotbar, corazones...) mientras dura el retorno. */
    private static void onGuiLayerPre(RenderGuiLayerEvent.Pre event) {
        if (ReturnEffect.active() && !event.getName().equals(ReturnEffect.LAYER_ID)) event.setCanceled(true);
    }
}
