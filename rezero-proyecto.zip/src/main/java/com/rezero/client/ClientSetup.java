package com.rezero.client;

import com.rezero.ReZero;
import net.minecraft.client.player.Input;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundSource;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.client.event.sound.PlaySoundEvent;
import net.neoforged.neoforge.common.NeoForge;

public final class ClientSetup {
    private ClientSetup() {}

    public static void init(IEventBus modBus) {
        modBus.addListener(ClientSetup::registerLayers);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onMovementInput);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onGuiLayerPre);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onInteraction);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onComputeFov);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onLogout);
        NeoForge.EVENT_BUS.addListener(ClientSetup::onPlaySound);
    }

    /** Capa de la animacion por encima de todo. */
    private static void registerLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(ReturnEffect.LAYER_ID, (graphics, deltaTracker) -> ReturnEffect.render(graphics));
    }

    /** Sin controles de movimiento mientras dura el retorno. */
    private static void onMovementInput(MovementInputUpdateEvent event) {
        if (!ReturnEffect.active()) return;
        Input in = event.getInput();
        in.up = false;
        in.down = false;
        in.left = false;
        in.right = false;
        in.jumping = false;
        in.shiftKeyDown = false;
        in.forwardImpulse = 0f;
        in.leftImpulse = 0f;
    }

    /** Sin pegar, usar ni romper nada mientras dura el retorno. */
    private static void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        if (!ReturnEffect.active()) return;
        event.setCanceled(true);
        event.setSwingHand(false);
    }

    /** Sin interfaz (hotbar, corazones...) mientras dura el retorno. */
    private static void onGuiLayerPre(RenderGuiLayerEvent.Pre event) {
        if (ReturnEffect.active() && !event.getName().equals(ReturnEffect.LAYER_ID)) event.setCanceled(true);
    }

    /** Efecto tunel / respiracion del campo de vision. */
    private static void onComputeFov(ViewportEvent.ComputeFov event) {
        float scale = ReturnEffect.fovScale();
        if (scale != 1f) event.setFOV(event.getFOV() * scale);
    }

    private static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ReturnEffect.reset();
    }

    /**
     * Sin musica de fondo de Minecraft (menu, juego, creativo, bajo el agua...). Los discos (categoria RECORDS) siguen
     * sonando, y la musica de este mod (namespace "rezero") tambien, para poder meter canciones nuevas mas adelante.
     */
    private static void onPlaySound(PlaySoundEvent event) {
        SoundInstance sound = event.getSound();
        if (sound == null) return;
        if (sound.getSource() == SoundSource.MUSIC && !ReZero.MODID.equals(sound.getLocation().getNamespace())) {
            event.setSound(null);
        }
    }
}
