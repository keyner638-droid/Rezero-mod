package com.rezero.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.rezero.ModSounds;
import com.rezero.ReZero;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;

/**
 * Animacion del Retorno por la Muerte (~2.6 s):
 *  1. La vision se cierra en tunel hacia el centro (viñeta negra con borde violeta) mientras el FOV se encoge.
 *  2. Negro con latidos violetas, hasta que el servidor avisa de que el mundo ya volvio (y como minimo hasta el
 *     momento en que suena el golpe fuerte del audio).
 *  3. Despertar: se abre una rendija, un sobresalto (se cierra un poco) y la vision se abre de golpe con un
 *     destello lavanda mientras el FOV vuelve a la normalidad.
 */
public final class ReturnEffect {
    public static final ResourceLocation LAYER_ID = ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "retorno_overlay");
    private static final ResourceLocation VIGNETTE = ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "textures/gui/vignette.png");

    private static final float CLOSE = 0.45f;        // s que tarda en cerrarse la vision
    private static final float WAKE_AT = 1.5f;       // s minimos antes de empezar a despertar
    private static final float MAX_HOLD = 15f;       // s: si el aviso del servidor no llega, se abre igual
    private static final float FLINCH_1 = 0.18f;     // fin de la rendija inicial
    private static final float FLINCH_2 = 0.32f;     // fin del sobresalto
    private static final float OPEN_TOTAL = 1.15f;   // duracion total del despertar
    private static final float MIN_FOV = 0.90f;      // FOV al estar en "tunel"

    private static final int DARK = 0xFF0A0612;      // negro con un toque violeta (igual que el borde de la textura)
    private static final int VIOLET = 0x6B2FD6;
    private static final int LAVENDER = 0xEADFFF;

    private static long startMs = -1;
    private static boolean serverDone = false;
    private static float wakeTime = -1f;

    private ReturnEffect() {}

    public static void start() {
        startMs = Util.getMillis();
        serverDone = false;
        wakeTime = -1f;
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.RETORNO.get(), 1.0F));
    }

    /** El servidor ya termino de devolver el mundo al pasado. */
    public static void finish() {
        serverDone = true;
    }

    public static void reset() {
        startMs = -1;
    }

    /** true mientras dura la animacion (sin controles ni interfaz). */
    public static boolean active() {
        return update();
    }

    // ---------- Linea de tiempo ----------
    private static float now() {
        return (Util.getMillis() - startMs) / 1000f;
    }

    private static boolean update() {
        if (startMs < 0) return false;
        float t = now();
        if (t > MAX_HOLD + 2f) {                 // quedo de una partida anterior
            startMs = -1;
            return false;
        }
        if (wakeTime < 0f && t >= WAKE_AT && (serverDone || t >= MAX_HOLD)) wakeTime = t;
        if (wakeTime >= 0f && t >= wakeTime + OPEN_TOTAL) {
            startMs = -1;
            return false;
        }
        return true;
    }

    /** Cuanto esta abierta la vision (0 = todo negro, 1 = sin efecto). */
    private static float openness(float t) {
        if (t < CLOSE) {
            float q = 1f - t / CLOSE;
            return q * q;
        }
        if (wakeTime < 0f || t < wakeTime) return 0f;
        float o = t - wakeTime;
        if (o < FLINCH_1) return lerp(0f, 0.12f, easeOut(o / FLINCH_1));
        if (o < FLINCH_2) return lerp(0.12f, 0.03f, smooth((o - FLINCH_1) / (FLINCH_2 - FLINCH_1)));
        return lerp(0.03f, 1f, easeOut(clamp01((o - FLINCH_2) / (OPEN_TOTAL - FLINCH_2))));
    }

    /** Multiplicador del FOV (efecto tunel al morir, respiracion al despertar). */
    public static float fovScale() {
        if (!update()) return 1f;
        float t = now();
        if (t < CLOSE) return lerp(1f, MIN_FOV, easeOut(t / CLOSE));
        if (wakeTime < 0f || t < wakeTime) return MIN_FOV;
        return lerp(MIN_FOV, 1f, easeOut(clamp01((t - wakeTime) / OPEN_TOTAL)));
    }

    // ---------- Dibujo ----------
    public static void render(GuiGraphics g) {
        if (!update()) return;
        float t = now();
        int w = g.guiWidth(), h = g.guiHeight();

        // Vision en tunel: un cuadrado con degradado radial en el centro y relleno solido alrededor.
        float side = openness(t) * (float) Math.hypot(w, h) * 3.9f;
        int half = Math.round(side / 2f);
        if (half < 2) {
            g.fill(0, 0, w, h, DARK);
        } else {
            int x0 = w / 2 - half, x1 = w / 2 + half, y0 = h / 2 - half, y1 = h / 2 + half;
            if (x0 > 0) g.fill(0, 0, x0, h, DARK);
            if (x1 < w) g.fill(x1, 0, w, h, DARK);
            int ax = Math.max(0, x0), bx = Math.min(w, x1);
            if (y0 > 0) g.fill(ax, 0, bx, y0, DARK);
            if (y1 < h) g.fill(ax, y1, bx, h, DARK);
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            g.blit(VIGNETTE, x0, y0, half * 2, half * 2, 0f, 0f, 512, 512, 512, 512);
            RenderSystem.disableBlend();
        }

        // Latidos violetas mientras esta todo negro (el primero coincide con el golpe del audio)
        if (t >= CLOSE && wakeTime < 0f) {
            float ht = t - CLOSE, cycle = 1.1f;
            int n = (int) (ht / cycle);
            float x = ht - n * cycle;
            float amp = n == 0 ? 1f : 0.5f;
            overlay(g, w, h, VIOLET, amp * (0.20f * pulse(x, 0.05f) + 0.12f * pulse(x, 0.32f)));
        }

        // Destello al despertar
        if (wakeTime >= 0f && t >= wakeTime) {
            float k = 1f - (t - wakeTime) / 0.40f;
            if (k > 0f) overlay(g, w, h, LAVENDER, 0.20f * k * k);
        }
    }

    private static void overlay(GuiGraphics g, int w, int h, int rgb, float alpha) {
        int a = (int) (clamp01(alpha) * 255f);
        if (a > 2) g.fill(0, 0, w, h, (a << 24) | rgb);
    }

    private static float pulse(float x, float center) {
        return x < center ? 0f : (float) Math.exp(-(x - center) / 0.09f);
    }

    private static float clamp01(float v) {
        return v < 0f ? 0f : Math.min(v, 1f);
    }

    private static float lerp(float a, float b, float p) {
        return a + (b - a) * p;
    }

    private static float easeOut(float p) {
        float q = 1f - clamp01(p);
        return 1f - q * q * q;
    }

    private static float smooth(float p) {
        p = clamp01(p);
        return p * p * (3f - 2f * p);
    }
}
