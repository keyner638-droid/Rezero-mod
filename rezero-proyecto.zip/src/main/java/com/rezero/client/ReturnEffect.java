package com.rezero.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.rezero.ReZero;
import com.rezero.ReturnVariant;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;

/**
 * Animacion del Retorno por la Muerte, todo con curvas suaves (sin cortes ni destellos bruscos):
 *  1. La vision se oscurece desde los bordes hacia el centro hasta quedar en negro, con el FOV cerrandose un poco.
 *  2. Negro con un latido violeta muy tenue, hasta que el servidor avisa de que el mundo ya volvio
 *     (y como minimo hasta {@link ReturnVariant#wakeSeconds}, que depende del audio que toco).
 *  3. Despertar: la oscuridad se aparta con un parpadeo pesado (casi se abre, se entrecierra, se abre del todo),
 *     con un brillo lavanda leve, y el FOV vuelve a la normalidad.
 * La variante LOVE queda en negro puro, sin latidos, todo lo que dura su audio.
 */
public final class ReturnEffect {
    public static final ResourceLocation LAYER_ID = ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "retorno_overlay");
    private static final ResourceLocation VIGNETTE = ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "textures/gui/vignette.png");

    private static final float CLOSE = 0.3f;          // s que tarda en oscurecerse (rapido: que no se vea el fondo)
    private static final float VEIL_START = 0.0f;     // s en que empieza a taparse el centro
    private static final float OPEN_TOTAL = 1.9f;     // s que dura el despertar
    private static final float EXTRA_WAIT = 12f;      // s extra de seguridad si no llega el aviso del servidor
    private static final float MIN_FOV = 0.95f;       // FOV al estar oscuro

    private static final float[] WAKE_X = {0f, 0.55f, 0.85f, OPEN_TOTAL};
    private static final float[] WAKE_VEIL = {1f, 0.45f, 0.62f, 0f};
    private static final float[] WAKE_VIG = {1f, 0.90f, 0.60f, 0f};

    private static final int DARK = 0x0A0612;         // negro con un toque violeta
    private static final int VIOLET = 0x6B2FD6;
    private static final int LAVENDER = 0xEADFFF;

    private static long startMs = -1;
    private static ReturnVariant variant = ReturnVariant.NORMAL;
    private static boolean serverDone = false;
    private static float wakeTime = -1f;

    private ReturnEffect() {}

    public static void start(ReturnVariant v) {
        variant = v;
        startMs = Util.getMillis();
        serverDone = false;
        wakeTime = -1f;
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(v.sound(), 1.0F, v.volume));
    }

    /** El servidor ya termino de devolver el mundo al pasado. */
    public static void finish() {
        serverDone = true;
    }

    public static void reset() {
        startMs = -1;
    }

    /** true mientras dura la animacion (sin controles ni interfaz). */
    public static boolean active() {
        return update();
    }

    // ---------- Linea de tiempo ----------
    private static float now() {
        return (Util.getMillis() - startMs) / 1000f;
    }

    private static boolean update() {
        if (startMs < 0) return false;
        float t = now();
        float maxHold = variant.wakeSeconds + EXTRA_WAIT;
        if (t > maxHold + OPEN_TOTAL + 2f) {      // quedo de una partida anterior
            startMs = -1;
            return false;
        }
        if (wakeTime < 0f && t >= variant.wakeSeconds && (serverDone || t >= maxHold)) wakeTime = t;
        if (wakeTime >= 0f && t >= wakeTime + OPEN_TOTAL) {
            startMs = -1;
            return false;
        }
        return true;
    }

    private static boolean awake(float t) {
        return wakeTime >= 0f && t >= wakeTime;
    }

    /** Multiplicador del FOV (se cierra al oscurecerse y "respira" al despertar). */
    public static float fovScale() {
        if (!update()) return 1f;
        float t = now();
        if (t < CLOSE) return lerp(1f, MIN_FOV, smoother(t / CLOSE));
        if (!awake(t)) return MIN_FOV;
        return lerp(MIN_FOV, 1f, smoother((t - wakeTime) / OPEN_TOTAL));
    }

    // ---------- Dibujo ----------
    public static void render(GuiGraphics g) {
        if (!update()) return;
        float t = now();
        int w = g.guiWidth(), h = g.guiHeight();
        boolean love = variant == ReturnVariant.LOVE;

        float veil, vig;
        if (t < CLOSE) {
            vig = smoother(t / CLOSE);
            veil = smoother((t - VEIL_START) / (CLOSE - VEIL_START));
        } else if (!awake(t)) {
            vig = 1f;
            veil = 1f;
        } else {
            float o = t - wakeTime;
            veil = keys(o, WAKE_X, WAKE_VEIL);
            vig = keys(o, WAKE_X, WAKE_VIG);
        }

        // 1) Vineteado suave estirado a la pantalla (no se usa en la variante de negro puro)
        if (!love && vig > 0.01f) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            g.setColor(1f, 1f, 1f, vig);
            g.blit(VIGNETTE, 0, 0, w, h, 0f, 0f, 512, 512, 512, 512);
            g.setColor(1f, 1f, 1f, 1f);
            RenderSystem.disableBlend();
        }

        // 2) Velo oscuro sobre todo
        overlay(g, w, h, love ? 0x000000 : DARK, veil);

        // 3) Latido violeta tenue mientras esta oscuro (dos golpes suaves por ciclo)
        if (!love && t >= CLOSE && !awake(t)) {
            float ht = t - CLOSE, cycle = 1.2f;
            int n = (int) (ht / cycle);
            float x = ht - n * cycle;
            float amp = n == 0 ? 1f : 0.6f;
            overlay(g, w, h, VIOLET, amp * (0.09f * bump(x, 0.10f) + 0.05f * bump(x, 0.42f)));
        }

        // 4) Brillo lavanda leve al despertar
        if (!love && awake(t)) {
            float o = t - wakeTime;
            overlay(g, w, h, LAVENDER, 0.10f * bump(o, 0.30f, 0.40f));
        }
    }

    private static void overlay(GuiGraphics g, int w, int h, int rgb, float alpha) {
        int a = (int) (clamp01(alpha) * 255f);
        if (a > 1) g.fill(0, 0, w, h, (a << 24) | rgb);
    }

    /** Interpolacion suave entre puntos clave. */
    private static float keys(float x, float[] xs, float[] ys) {
        if (x <= xs[0]) return ys[0];
        for (int i = 1; i < xs.length; i++) {
            if (x < xs[i]) return lerp(ys[i - 1], ys[i], smooth((x - xs[i - 1]) / (xs[i] - xs[i - 1])));
        }
        return ys[ys.length - 1];
    }

    private static float bump(float x, float center) {
        return bump(x, center, 0.11f);
    }

    private static float bump(float x, float center, float width) {
        float d = (x - center) / width;
        return (float) Math.exp(-d * d);
    }

    private static float clamp01(float v) {
        return v < 0f ? 0f : Math.min(v, 1f);
    }

    private static float lerp(float a, float b, float p) {
        return a + (b - a) * p;
    }

    private static float smooth(float p) {
        p = clamp01(p);
        return p * p * (3f - 2f * p);
    }

    private static float smoother(float p) {
        p = clamp01(p);
        return p * p * p * (p * (p * 6f - 15f) + 10f);
    }
}
