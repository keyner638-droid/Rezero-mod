package com.rezero.client;

import com.rezero.ModSounds;
import com.rezero.ReZero;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;

/**
 * Animacion del retorno (los mismos tiempos del addon de Bedrock): negro inicial y tres parpadeos.
 * Cada tramo es {inicio, entra, mantiene, sale} en segundos.
 */
public final class ReturnEffect {
    public static final ResourceLocation LAYER_ID = ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "retorno_overlay");

    private static final float[][] FADES;
    private static final float TOTAL;

    static {
        List<float[]> list = new ArrayList<>();
        list.add(new float[] {0f, 0.1f, 1.5f, 0.4f});
        float t = 2.0f;
        float[][] blinks = {
                {0.5f, 0.15f, 0.25f, 0.35f},
                {0.6f, 0.12f, 0.15f, 0.30f},
                {0.8f, 0.10f, 0.10f, 0.50f},
        };
        for (float[] b : blinks) {          // {pausa, cierra, negro, abre}
            t += b[0];
            list.add(new float[] {t, b[1], b[2], b[3]});
            t += b[1] + b[2] + b[3];
        }
        FADES = list.toArray(new float[0][]);
        TOTAL = t;
    }

    private static long startMs = -1;

    private ReturnEffect() {}

    public static void start() {
        startMs = Util.getMillis();
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.RETORNO.get(), 1.0F));
    }

    public static boolean active() {
        return startMs >= 0 && (Util.getMillis() - startMs) / 1000f < TOTAL;
    }

    /** Opacidad del negro ahora mismo (0 a 1). */
    public static float alpha() {
        if (startMs < 0) return 0f;
        float now = (Util.getMillis() - startMs) / 1000f;
        float best = 0f;
        for (float[] f : FADES) {
            float dt = now - f[0];
            if (dt < 0f) continue;
            float a;
            if (dt < f[1]) a = dt / f[1];
            else if (dt < f[1] + f[2]) a = 1f;
            else if (dt < f[1] + f[2] + f[3]) a = 1f - (dt - f[1] - f[2]) / f[3];
            else a = 0f;
            best = Math.max(best, a);
        }
        return best;
    }
}
