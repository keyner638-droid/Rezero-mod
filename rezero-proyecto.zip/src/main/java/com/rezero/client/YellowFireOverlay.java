package com.rezero.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.rezero.ModEffects;
import com.rezero.ReZero;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;

/** Llamas amarillas en la parte de abajo de la pantalla mientras se arde con fuego amarillo (como el fuego normal, pero amarillo). */
public final class YellowFireOverlay {
    public static final ResourceLocation LAYER_ID = ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "yellow_fire");
    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "textures/gui/yellow_fire.png");
    /** La textura son 4 cuadros de 32x32 uno encima de otro. */
    private static final int FRAME = 32, FRAMES = 4;

    private YellowFireOverlay() {}

    public static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || p.isSpectator() || !p.hasEffect(ModEffects.YELLOW_FIRE)) return;

        int w = g.guiWidth(), h = g.guiHeight();
        int big = Math.max(48, h / 3);
        RenderSystem.enableBlend();
        // Fila de atras (mas pequena y mas transparente) y fila de delante
        for (int row = 1; row >= 0; row--) {
            int size = row == 0 ? big : (int) (big * 0.7f);
            g.setColor(1.0F, 1.0F, 1.0F, row == 0 ? 0.9F : 0.6F);
            int count = w / size + 2;
            for (int i = 0; i < count; i++) {
                int frame = (p.tickCount / 2 + i * 3 + row * 2) % FRAMES;
                int x = i * size - size / 2 + row * (size / 3);
                g.blit(TEX, x, h - size, size, size, 0f, frame * FRAME, FRAME, FRAME, FRAME, FRAME * FRAMES);
            }
        }
        g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }
}
