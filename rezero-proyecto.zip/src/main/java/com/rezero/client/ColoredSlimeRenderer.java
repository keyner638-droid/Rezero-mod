package com.rezero.client;

import com.rezero.ReZero;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.SlimeRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Slime;

/** Renderer del slime vanilla con otra textura (textures/entity/<name>.png). */
public class ColoredSlimeRenderer extends SlimeRenderer {
    private final ResourceLocation texture;

    public ColoredSlimeRenderer(EntityRendererProvider.Context context, String name) {
        super(context);
        this.texture = ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "textures/entity/" + name + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(Slime entity) {
        return texture;
    }
}
