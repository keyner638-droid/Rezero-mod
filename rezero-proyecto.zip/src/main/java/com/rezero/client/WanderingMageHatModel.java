package com.rezero.client;

import com.rezero.ReZero;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/**
 * Modelo del sombrero cuando se lleva puesto (reemplaza al modelo de casco normal).
 * Textura: textures/models/armor/wandering_mage_hat_layer_1.png (128x128, mismos UV que el sombrero del zombie).
 */
public class WanderingMageHatModel extends HumanoidModel<LivingEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "wandering_mage_hat"), "main");

    public WanderingMageHatModel(ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();
        // La cabeza y la capa "hat" se vacian: solo queda el sombrero colgando de la cabeza.
        PartDefinition head = root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);
        WanderingZombieMageModel.addHat(head);
        return LayerDefinition.create(mesh, 128, 128);
    }
}
