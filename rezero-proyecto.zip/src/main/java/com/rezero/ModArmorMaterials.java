package com.rezero;

import java.util.EnumMap;
import java.util.List;
import net.minecraft.Util;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModArmorMaterials {
    public static final DeferredRegister<ArmorMaterial> MATERIALS =
            DeferredRegister.create(Registries.ARMOR_MATERIAL, ReZero.MODID);

    /** Sin defensa: el sombrero solo da sus efectos de mana. La textura de la capa se usa con el modelo 3D propio. */
    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> WANDERING_MAGE_HAT =
            MATERIALS.register("wandering_mage_hat", () -> new ArmorMaterial(
                    Util.make(new EnumMap<>(ArmorItem.Type.class), m -> {
                        m.put(ArmorItem.Type.BOOTS, 0);
                        m.put(ArmorItem.Type.LEGGINGS, 0);
                        m.put(ArmorItem.Type.CHESTPLATE, 0);
                        m.put(ArmorItem.Type.HELMET, 0);
                        m.put(ArmorItem.Type.BODY, 0);
                    }),
                    0,
                    SoundEvents.ARMOR_EQUIP_LEATHER,
                    () -> Ingredient.EMPTY,
                    List.of(new ArmorMaterial.Layer(ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "wandering_mage_hat"))),
                    0.0F,
                    0.0F));

    private ModArmorMaterials() {}
}
