package com.rezero.net;

import com.rezero.ReZero;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Servidor -> cliente: monedas (en cobre) y XP total del jugador. */
public record CoinsPayload(long copper, long xp) implements CustomPacketPayload {
    public static final Type<CoinsPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "monedas"));
    public static final StreamCodec<ByteBuf, CoinsPayload> STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.VAR_LONG, CoinsPayload::copper,
                    ByteBufCodecs.VAR_LONG, CoinsPayload::xp,
                    CoinsPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
