package com.rezero.net;

import com.rezero.ReZero;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Servidor -> cliente: el mundo ya volvio al pasado, se puede "abrir los ojos". */
public record ReturnEndPayload() implements CustomPacketPayload {
    public static final Type<ReturnEndPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "retorno_fin"));
    public static final StreamCodec<ByteBuf, ReturnEndPayload> STREAM_CODEC = StreamCodec.unit(new ReturnEndPayload());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
