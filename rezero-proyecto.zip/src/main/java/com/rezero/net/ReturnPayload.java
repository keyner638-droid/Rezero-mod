package com.rezero.net;

import com.rezero.ReZero;
import com.rezero.ReturnVariant;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Servidor -> cliente: empieza la animacion del retorno. {@code variant} es el indice de {@link ReturnVariant}. */
public record ReturnPayload(int variant) implements CustomPacketPayload {
    public static final Type<ReturnPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "retorno"));
    public static final StreamCodec<ByteBuf, ReturnPayload> STREAM_CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT, ReturnPayload::variant, ReturnPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
