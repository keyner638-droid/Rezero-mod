package com.rezero.net;

import com.rezero.ReZero;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Servidor -> cliente: empieza la animacion del retorno (negro, parpadeos y sonido). */
public record ReturnPayload() implements CustomPacketPayload {
    public static final Type<ReturnPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(ReZero.MODID, "retorno"));
    public static final StreamCodec<ByteBuf, ReturnPayload> STREAM_CODEC = StreamCodec.unit(new ReturnPayload());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
